#ifndef _CDspDistDBSVisitor_H_
#define _CDspDistDBSVisitor_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDistDBSVisitor CDspDistDBSVisitor;
typedef struct _CDspDistDBS CDspDistDBS;

struct _CDspDistDBSVisitor
{
	void (*FP_visitDspDistDBS)(CDspDistDBSVisitor* pThis, CDspDistDBS* dspDistDBS);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDistDBSVisitor* getDspDistDBSVisitor(char* url);
void CDspDistDBSVisitor_ctor(CDspDistDBSVisitor* pThis, char* url);
void CDspDistDBSVisitor_dtor(CDspDistDBSVisitor* pThis);
void CDspDistDBSVisitor_visitDspDistDBS(CDspDistDBSVisitor* pThis, CDspDistDBS* dspDistDBS);
#endif
