#include <stdio.h>
#include <assert.h>
#include "CDspDistDBSVisitor.h"
#include "CDspDistDBS.h"

#define URL "mongodb://localhost:27017"
void dspDistDBS();
int main(int argc, char* argv[])
{
	CDspDistDBS* pThis = getDspDistDBS();
	char* url = (2 == argc) ? argv[1] : URL;
	
	dspDistDBS(pThis, url);
	CDspDistDBS_dtor(pThis);
	return 0;
}
void dspDistDBS(CDspDistDBS* pThis, char* url)
{
	CDspDistDBSVisitor* visit = getDspDistDBSVisitor(url);
	
	CDspDistDBS_accept(pThis, visit);
	while(0 != pThis->next) {
		printf("%s\n", pThis->colName);
		pThis = pThis->next;
	}
	CDspDistDBSVisitor_dtor(visit);
}
