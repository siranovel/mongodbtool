#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CDspDistDBS.h"
#include "CDspDistDBSVisitor.h"

static void CDspDistDBS_setFuncPoint(CDspDistDBS* pThis);
static void CDspDistDBS_doAccept(CDspDistDBS* pThis, CDspDistDBSVisitor* visit);
CDspDistDBS* getDspDistDBS()
{
	CDspDistDBS* pThis = malloc(sizeof(CDspDistDBS));
	
	CDspDistDBS_ctor(pThis);
	return pThis;
}
void CDspDistDBS_ctor(CDspDistDBS* pThis)
{
	CDspDistDBS_setFuncPoint(pThis);
	pThis->next = 0;
}
static void CDspDistDBS_setFuncPoint(CDspDistDBS* pThis)
{
	pThis->FP_accept = CDspDistDBS_doAccept;
}
void CDspDistDBS_dtor(CDspDistDBS* pThis)
{
	free(pThis);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDistDBS_accept(CDspDistDBS* pThis, CDspDistDBSVisitor* visit)
{
	assert(0 != pThis);
	assert(0 != visit);
	pThis->FP_accept(pThis, visit);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDistDBS_doAccept(CDspDistDBS* pThis, CDspDistDBSVisitor* visit)
{
	CDspDistDBSVisitor_visitDspDistDBS(visit, pThis);
}
