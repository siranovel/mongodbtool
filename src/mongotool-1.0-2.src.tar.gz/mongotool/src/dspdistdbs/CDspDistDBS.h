#ifndef _CDspDistDBS_H_
#define _CDspDistDBS_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDistDBS CDspDistDBS;
typedef struct _CDspDistDBSVisitor CDspDistDBSVisitor;

struct _CDspDistDBS
{
	CDspDistDBS* next;
	char* colName;
	void (*FP_accept)(CDspDistDBS* pThis, CDspDistDBSVisitor* visit);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDistDBS* getDspDistDBS();
void CDspDistDBS_ctor(CDspDistDBS* pThis);
void CDspDistDBS_dtor(CDspDistDBS* pThis);
void CDspDistDBS_accept(CDspDistDBS* pThis, CDspDistDBSVisitor* visit);
#endif
