#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CDspDistDBSVisitor.h"
#include "CDspDistDBS.h"

static mongoc_client_t* _client = 0;
static void CDspDistDBSVisitor_doVisitDspDistDBS(CDspDistDBSVisitor* pThis, CDspDistDBS* dspDistDBS);
static CDspDistDBSVisitor _visit = {
	.FP_visitDspDistDBS = CDspDistDBSVisitor_doVisitDspDistDBS,
};
CDspDistDBSVisitor* getDspDistDBSVisitor(char* url)
{
	CDspDistDBSVisitor_ctor(&_visit, url);
	return &_visit;
}
void CDspDistDBSVisitor_ctor(CDspDistDBSVisitor* pThis, char* url)
{
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "dspdistdbs");
}
void CDspDistDBSVisitor_dtor(CDspDistDBSVisitor* pThis)
{
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDistDBSVisitor_visitDspDistDBS(CDspDistDBSVisitor* pThis, CDspDistDBS* dspDistDBS)
{
	assert(0 != pThis);
	pThis->FP_visitDspDistDBS(pThis, dspDistDBS);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDistDBSVisitor_doVisitDspDistDBS(CDspDistDBSVisitor* pThis, CDspDistDBS* dspDistDBS)
{
	CDspDistDBS* w = dspDistDBS;
    bson_error_t error;
	char** names = 0;
	int i = 0;
	mongoc_database_t* db = mongoc_client_get_database(_client, "distdb");
	
	names = mongoc_database_get_collection_names_with_opts(db, NULL, &error);
	for (i = 0; names[i] != 0; i++) {
		w->next = getDspDistDBS();
		w->colName = names[i];
		w = w->next;
	}
	
}
