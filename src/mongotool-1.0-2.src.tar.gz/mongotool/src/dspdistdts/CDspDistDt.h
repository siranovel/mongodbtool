#ifndef _CDspDistDt_H_
#define _CDspDistDt_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDistDt CDspDistDt;
typedef struct _CDspDistDtsVisitor CDspDistDtsVisitor;
typedef enum _MONGO_TYPE  MONGO_TYPE;

enum _MONGO_TYPE {
	MONGO_TYPE_OID    = 0,
	MONGO_TYPE_DOUBLE = 1,
	MONGO_TYPE_INT32  = 2
};
struct _CDspDistDt
{
	CDspDistDt* next;
	const char* key;
	MONGO_TYPE  type;
	void* val;
	void (*FP_accept)(CDspDistDt* pThis, CDspDistDtsVisitor* visit);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDistDt* getDspDistDt();
void CDspDistDt_ctor(CDspDistDt* pThis);
void CDspDistDt_dtor(CDspDistDt* pThis);
void CDspDistDt_accept(CDspDistDt* pThis, CDspDistDtsVisitor* visit);
#endif
