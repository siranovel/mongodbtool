#ifndef _CDspDistDtsVisitor_H_
#define _CDspDistDtsVisitor_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDistDtsVisitor CDspDistDtsVisitor;
typedef struct _CDspDistDts CDspDistDts;
typedef struct _CDspDistDt CDspDistDt;

struct _CDspDistDtsVisitor
{
	void (*FP_visitDspDistDts)(CDspDistDtsVisitor* pThis, CDspDistDts* dspDistDts);
	void (*FP_visitDspDistDt)(CDspDistDtsVisitor* pThis, CDspDistDt* CDspDistDt);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDistDtsVisitor* getDspDistDtsVisitor(char* url, char* tblName);
void CDspDistDtsVisitor_ctor(CDspDistDtsVisitor* pThis, char* url, char* tblName);
void CDspDistDtsVisitor_dtor(CDspDistDtsVisitor* pThis);
void CDspDistDtsVisitor_visitDspDistDts(CDspDistDtsVisitor* pThis, CDspDistDts* dspDistDts);
void CDspDistDtsVisitor_visitDspDistDt(CDspDistDtsVisitor* pThis, CDspDistDt* CDspDistDt);
#endif
