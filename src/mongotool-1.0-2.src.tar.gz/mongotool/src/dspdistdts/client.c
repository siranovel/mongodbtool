#include <stdio.h>
#include <assert.h>
#include "CDspDistDtsVisitor.h"
#include "CDspDistDts.h"
#include "CDspDistDt.h"


#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void dspDistDts(CDspDistDts* pThis, char* url, char* tblName);
static void dspDistDt(CDspDistDt* dspDistDt);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* tblName = argv[1];
	char* url = (3 == argc) ? argv[2] : URL;
	CDspDistDts* pThis = getDspDistDts();
	
	dspDistDts(pThis, url, tblName);
	CDspDistDts_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <tableName> | <mongodbURL>\n", exeNm);
	printf("\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void dspDistDts(CDspDistDts* pThis, char* url, char* tblName)
{
	CDspDistDtsVisitor* visit = getDspDistDtsVisitor(url, tblName);
	
	CDspDistDts_accept(pThis, visit);
	while(0 != pThis->next) {
		dspDistDt(pThis->dspDistDt);
		pThis = pThis->next;
	}
	CDspDistDtsVisitor_dtor(visit);
	
	
}
static void dspDistDt(CDspDistDt* dspDistDt)
{
	CDspDistDt* w = dspDistDt;
	
	while(0 != w->next) {
		printf("%s: ", w->key);
		switch(w->type) {
		case MONGO_TYPE_OID:
			printf("%s ", (char*)w->val);
			break;
		case MONGO_TYPE_DOUBLE:
			printf("%lf ", *((double*)w->val));
			break;
		case MONGO_TYPE_INT32:
			printf("%d ", *((int*)w->val));
			break;
		default:
			break;
		}
		w = w->next;
	}
	printf("\n");
}
