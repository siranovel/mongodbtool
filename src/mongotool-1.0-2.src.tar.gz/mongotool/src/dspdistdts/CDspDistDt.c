#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CDspDistDt.h"
#include "CDspDistDtsVisitor.h"

static void CDspDistDt_setFuncPoint(CDspDistDt* pThis);
static void CDspDistDt_doAccept(CDspDistDt* pThis, CDspDistDtsVisitor* visit);
CDspDistDt* getDspDistDt()
{
	CDspDistDt* pThis = malloc(sizeof(CDspDistDt));
	
	CDspDistDt_ctor(pThis);
	return pThis;
}
void CDspDistDt_ctor(CDspDistDt* pThis)
{
	CDspDistDt_setFuncPoint(pThis);
	pThis->next = 0;
}
static void CDspDistDt_setFuncPoint(CDspDistDt* pThis)
{
	pThis->FP_accept = CDspDistDt_doAccept;
}
void CDspDistDt_dtor(CDspDistDt* pThis)
{
	free(pThis);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDistDt_accept(CDspDistDt* pThis, CDspDistDtsVisitor* visit)
{
	pThis->FP_accept(pThis, visit);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDistDt_doAccept(CDspDistDt* pThis, CDspDistDtsVisitor* visit)
{
	CDspDistDtsVisitor_visitDspDistDt(visit, pThis);
}
