#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CDspDistDts.h"
#include "CDspDistDtsVisitor.h"
#include "CDspDistDt.h"

static void CDspDistDts_setFuncPoint(CDspDistDts* pThis);
static void CDspDistDts_doAccept(CDspDistDts* pThis, CDspDistDtsVisitor* visit);
CDspDistDts* getDspDistDts()
{
	CDspDistDts* pThis = malloc(sizeof(CDspDistDts));
	
	CDspDistDts_ctor(pThis);
	return pThis;
}
void CDspDistDts_ctor(CDspDistDts* pThis)
{
	CDspDistDts_setFuncPoint(pThis);
	pThis->next = 0;
}
static void CDspDistDts_setFuncPoint(CDspDistDts* pThis)
{
	pThis->FP_accept = CDspDistDts_doAccept;
}
void CDspDistDts_dtor(CDspDistDts* pThis)
{
	free(pThis);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDistDts_accept(CDspDistDts* pThis, CDspDistDtsVisitor* visit)
{
	assert(0 != pThis);
	assert(0 != visit);
	pThis->FP_accept(pThis, visit);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDistDts_doAccept(CDspDistDts* pThis, CDspDistDtsVisitor* visit)
{
	CDspDistDtsVisitor_visitDspDistDts(visit, pThis);
}
