#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CDspDistDtsVisitor.h"
#include "CDspDistDts.h"
#include "CDspDistDt.h"


static mongoc_client_t* _client = 0;
static const bson_t* _doc;
static char* _tblName = 0;
static void CDspDistDtsVisitor_doVisitDspDistDts(CDspDistDtsVisitor* pThis, CDspDistDts* dspDistDts);
static void CDspDistDtsVisitor_doVisitDspDistDt(CDspDistDtsVisitor* pThis, CDspDistDt* dspDistDt);
static CDspDistDtsVisitor _visit = {
	.FP_visitDspDistDts = CDspDistDtsVisitor_doVisitDspDistDts,
	.FP_visitDspDistDt = CDspDistDtsVisitor_doVisitDspDistDt,
};
CDspDistDtsVisitor* getDspDistDtsVisitor(char* url, char* tblName)
{
	CDspDistDtsVisitor_ctor(&_visit, url, tblName);
	return &_visit;
}
void CDspDistDtsVisitor_ctor(CDspDistDtsVisitor* pThis, char* url, char* tblName)
{
	_tblName = tblName;
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "dspdistdts");
}
void CDspDistDtsVisitor_dtor(CDspDistDtsVisitor* pThis)
{
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDistDtsVisitor_visitDspDistDts(CDspDistDtsVisitor* pThis, CDspDistDts* dspDistDts)
{
	assert(0 != pThis);
	pThis->FP_visitDspDistDts(pThis, dspDistDts);
}
void CDspDistDtsVisitor_visitDspDistDt(CDspDistDtsVisitor* pThis, CDspDistDt* CDspDistDt)
{
	pThis->FP_visitDspDistDt(pThis, CDspDistDt);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDistDtsVisitor_doVisitDspDistDts(CDspDistDtsVisitor* pThis, CDspDistDts* dspDistDts)
{
	CDspDistDts* w = dspDistDts;
	bson_t* query = bson_new();
    bson_error_t error;
	mongoc_database_t* db = mongoc_client_get_database(_client, "distdb");
	
	if (!mongoc_database_has_collection(db, _tblName, &error)) {
		fprintf(stderr, "%s is not exist\n", _tblName);
		return;
	}
	
    mongoc_collection_t* coll = mongoc_database_get_collection(db, _tblName);
	mongoc_cursor_t* cur = mongoc_collection_find_with_opts(coll, query, NULL, NULL);
	
	
	while(mongoc_cursor_next(cur, &_doc)) {
		w->next = getDspDistDts();
		w->dspDistDt = getDspDistDt();
		CDspDistDt_accept(w->dspDistDt, pThis);
		w = w->next;
	}
	bson_destroy(query);
	mongoc_cursor_destroy(cur);
	mongoc_collection_destroy(coll);
	
}
static void CDspDistDtsVisitor_doVisitDspDistDt(CDspDistDtsVisitor* pThis, CDspDistDt* dspDistDt)
{
	bson_iter_t iter;
	CDspDistDt* w = dspDistDt;
	
	if (!bson_iter_init(&iter, _doc)) {
		printf("bson_iter_t init error\n");
	}
	while(bson_iter_next(&iter)) {
		w->next = getDspDistDt();
		w->key = bson_iter_key(&iter);
		if (BSON_ITER_HOLDS_OID(&iter)) {
			const bson_oid_t* oid = bson_iter_oid(&iter);
			
			w->type = MONGO_TYPE_OID;
			w->val = malloc(25);
			bson_oid_to_string(oid, w->val);
			
		}
		if (BSON_ITER_HOLDS_DOUBLE(&iter)) {
			w->type = MONGO_TYPE_DOUBLE;
			w->val = malloc(sizeof(double));
			*((double*)w->val) = bson_iter_double(&iter);
			
		}
		if (BSON_ITER_HOLDS_INT32(&iter)) {
			w->type = MONGO_TYPE_INT32;
			w->val = malloc(sizeof(long));
			*((int*)w->val) = bson_iter_int32(&iter);
		}
		w = w->next;
	}
}
