#ifndef _CDspDistDts_H_
#define _CDspDistDts_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDistDts CDspDistDts;
typedef struct _CDspDistDtsVisitor CDspDistDtsVisitor;
typedef struct _CDspDistDt CDspDistDt;

struct _CDspDistDts
{
	CDspDistDts* next;
	CDspDistDt* dspDistDt;
	void (*FP_accept)(CDspDistDts* pThis, CDspDistDtsVisitor* visit);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDistDts* getDspDistDts();
void CDspDistDts_ctor(CDspDistDts* pThis);
void CDspDistDts_dtor(CDspDistDts* pThis);
void CDspDistDts_accept(CDspDistDts* pThis, CDspDistDtsVisitor* visit);
#endif
