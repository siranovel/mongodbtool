#include <stdio.h>
#include <assert.h>
#include "CCrtBeBiDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtBeBi(CCrtBeBiDist* pThis, int trials);

int main(int argc, char* argv[])
{
	int trials = 0;
	double alpha = 0.0;
	double beta = 0.0;
	
	if (5 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &trials);
	sscanf(argv[3], "%lf", &alpha);
	sscanf(argv[4], "%lf", &beta);
	char* url = (6 == argc) ? argv[5] : URL;
	
    CCrtBeBiDist* pThis = getCrtBeBiDist(updModPth, url, trials, alpha, beta);
	
	crtBeBi(pThis, trials);
	CCrtBeBiDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <trials> <alpha> <beta> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\ttrials > 0\n");
	printf("\talpha > 0\n");
	printf("\tbeta > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtBeBi(CCrtBeBiDist* pThis, int trials)
{
    int x;
	
	for (x = 0; x <= trials; x++) {
		CCrtBeBiDist_crtBeBi(pThis, x);
	}
}
