#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CCrtBeBiDist.h"
#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JConfiguration.h"
#include "JGamma.h"
#include "JCombinatoricsUtils.h"

static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static mongoc_collection_t* _coll = 0;
static mongoc_client_t* _client = 0;
static jobject _emptyM = 0;
static int _trials = 0;
static double _alpha = 0.0;
static double _beta = 0.0;
static jdouble _bab = 0.0;
static jdouble _gabx = 0.0;

static void CCrtBeBiDist_doCrtBeBi(CCrtBeBiDist* pThis, int x);
static int64_t cntBeBi(int x);
static void insBeBi(int x);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);
static CCrtBeBiDist _cCrtBeBiDist = {
	.FP_crtBeBi = CCrtBeBiDist_doCrtBeBi,
};

CCrtBeBiDist* getCrtBeBiDist(char* modPth, char* url, int trials, double alpha, double beta)
{
	CCrtBeBiDist_ctor(&_cCrtBeBiDist, modPth, url, trials, alpha, beta);
	return &_cCrtBeBiDist;
}
void CCrtBeBiDist_ctor(CCrtBeBiDist* pThis, char* modPth, char* url, int trials, double alpha, double beta)
{
	init();
	updModPth(modPth);
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "crtbebidist");
    _coll = mongoc_client_get_collection(_client, "distdb", "bebi");
	
	_trials = trials;
	_alpha = alpha;
	_beta = beta;
//	double ax = a + x;
//	double bx = b + n - x;
// ax + bx = a + x + b + n - x = a + b + n
	jdouble ga = JGamma_gamma(_env, _emptyM, alpha);
	jdouble gb = JGamma_gamma(_env, _emptyM, beta);
	jdouble gab = JGamma_gamma(_env, _emptyM, alpha + beta);
	_bab = ga * gb / gab;
	
	_gabx = JGamma_gamma(_env, _emptyM, alpha + beta + trials);
}
void CCrtBeBiDist_dtor(CCrtBeBiDist* pThis)
{
	end();
	if (_coll)
	    mongoc_collection_destroy(_coll);
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CCrtBeBiDist_crtBeBi(CCrtBeBiDist* pThis, int x)
{
	assert(0 != pThis);
	pThis->FP_crtBeBi(pThis, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CCrtBeBiDist_doCrtBeBi(CCrtBeBiDist* pThis, int x)
{
	if (0 == cntBeBi(x)) {
		insBeBi(x);
	}
}
static int64_t cntBeBi(int x)
{
    bson_t* doc;
    int64_t count;
	bson_t  reply;
    bson_error_t error;

	doc = bson_new();
	BSON_APPEND_INT32(doc, "n", _trials);
	BSON_APPEND_DOUBLE(doc, "a", _alpha);
	BSON_APPEND_DOUBLE(doc, "b", _beta);
	BSON_APPEND_INT32(doc, "x", x);
	count = mongoc_collection_count_documents(_coll, doc, NULL, NULL, &reply, &error);
	if (count < 0) {
		fprintf(stderr, "%s\n", error.message);
	}
	
	bson_destroy(doc);
	return count;
	
}
static void insBeBi(int x)
{
	// Beta(a,b) = ��(a)��(b)/��(a+b)
	//           = (a-1)!(b-1)!/(a+b-1)!
	// BetaBi(n,a,b) = p(X=x) 
	//               = nCx*Beta(a+x, b+n-x)/Beta(a,b)
	jlong ncx = JCombinatoricsUtils_binomialCoefficient(_env, _emptyM, _trials, x);
	double ax = _alpha + x;
	double bx = _beta + _trials - x;
	double gax = JGamma_gamma(_env, _emptyM, ax);
	double gbx = JGamma_gamma(_env, _emptyM, bx);
	double babx = gax * gbx / _gabx;
	double bp = ncx * babx / _bab;
	
    bson_error_t error;
    bson_oid_t oid;
    bson_t* doc;
	
	doc = bson_new();
	bson_oid_init(&oid, NULL);
	BSON_APPEND_OID(doc, "_id", &oid);
	BSON_APPEND_INT32(doc, "n", _trials);
	BSON_APPEND_DOUBLE(doc, "a", _alpha);
	BSON_APPEND_DOUBLE(doc, "b", _beta);
	BSON_APPEND_INT32(doc, "x", x);
	BSON_APPEND_DOUBLE(doc, "p", bp);
	
	if (!mongoc_collection_insert_one(_coll, doc, NULL, NULL, &error)) {
		fprintf(stderr, "%s\n", error.message);
	}
	bson_destroy(doc);
}

static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	,{.optionString = "-XX:+UseJVMCICompiler", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, modPth);
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	_emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
	
	// 
	
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
