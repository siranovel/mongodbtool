#include <stdio.h>
#include <assert.h>
#include "JCombinatoricsUtils.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jlong JCombinatoricsUtils_doBinomialCoefficient(JNIEnv* env, jobject emptyM, jint n, jint k);
static JCombinatoricsUtils _jCombinatoricsUtils = {
	.FP_binomialCoefficient = JCombinatoricsUtils_doBinomialCoefficient
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jlong JCombinatoricsUtils_binomialCoefficient(JNIEnv* env, jobject emptyM, jint n, jint k)
{
	assert(0 != env);
	assert(0 != emptyM);
	return _jCombinatoricsUtils.FP_binomialCoefficient(env, emptyM, n, k);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jlong JCombinatoricsUtils_doBinomialCoefficient(JNIEnv* env, jobject emptyM, jint n, jint k)
{
	jvalue argValues[] = {
		[0] = { .i = n},
		[1] = { .i = k},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,CombinatoricsUtils));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "binomialCoefficient", "(II)J");
	
	return JClass_CallStaticLongMethodA(env, clz, mid, argValues);
	
}
