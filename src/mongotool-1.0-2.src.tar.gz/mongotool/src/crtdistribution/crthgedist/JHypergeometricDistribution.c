#include <stdio.h>
#include <assert.h>
#include "JHypergeometricDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewHypergeometricDistribution(JNIEnv* env, jobject emptyM, jint populationSize, jint numberOfSuccesses, jint sampleSize);
static jint JHypergeometricDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject hgedistObj, jdouble p);
static JHypergeometricDistribution _jHgeDist = {
	.FP_inverseCumulativeProbability = JHypergeometricDistribution_doInverseCumulativeProbability,
};
jobject newHypergeometricDistribution(JNIEnv* env, jobject emptyM, jint populationSize, jint numberOfSuccesses, jint sampleSize)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewHypergeometricDistribution(env, emptyM, populationSize, numberOfSuccesses, sampleSize);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jint JHypergeometricDistribution_inverseCumulativeProbability(JNIEnv* env, jobject hgedistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != hgedistObj);
	return _jHgeDist.FP_inverseCumulativeProbability(env, hgedistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewHypergeometricDistribution(JNIEnv* env, jobject emptyM, jint populationSize, jint numberOfSuccesses, jint sampleSize)
{
	jvalue argValues[] = {
		[0] = { .i = populationSize},
		[1] = { .i = numberOfSuccesses},
		[2] = { .i = sampleSize},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,HGE_DIST));
	
	return JClass_NewObjectA(env, clz, "(III)V", argValues);
}
static jint JHypergeometricDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject hgedistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, hgedistObj), "inverseCumulativeProbability", "(D)I");
	return JClass_CallIntMethodA(env, hgedistObj, mid, argValues);
}
