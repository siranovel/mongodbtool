#ifndef _JHypergeometricDistribution_H_
#define _JHypergeometricDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JHypergeometricDistribution JHypergeometricDistribution;

struct _JHypergeometricDistribution
{
	jint (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject hgedistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define HGE_DIST "org.apache.commons.math3.distribution.HypergeometricDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newHypergeometricDistribution(JNIEnv* env, jobject emptyM, jint populationSize, jint numberOfSuccesses, jint sampleSize);
jint JHypergeometricDistribution_inverseCumulativeProbability(JNIEnv* env, jobject hgedistObj, jdouble p);
#endif
