#include <stdio.h>
#include <assert.h>
#include "CCrtHGeDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtHGeDist(CCrtHGeDist* pThis, int populationSize);
int main(int argc, char* argv[])
{
	int populationSize;
	
	if (3 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &populationSize);
	char* url = (4 == argc) ? argv[3] : URL;
	CCrtHGeDist* pThis = getCrtHGeDist(updModPth, url);
	
	crtHGeDist(pThis, populationSize);
	CCrtHGeDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <populationSize> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tpopulationSize > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtHGeDist(CCrtHGeDist* pThis, int populationSize)
{
	int i;
	int j;
	
	for (j = 0; j < populationSize; j++) {
		for (i = 0; i < populationSize; i++) {
			CCrtHGeDist_crtHGeDist(pThis, populationSize, i+1, j+1, 0.05);
		}
	}
}
