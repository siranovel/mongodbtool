#ifndef _CCrtHGeDist_H_
#define _CCrtHGeDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtHGeDist CCrtHGeDist;

struct _CCrtHGeDist
{
	void (*FP_crtHGeDist)(CCrtHGeDist* pThis, int populationSize, int numberOfSuccesses, int sampleSize, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtHGeDist* getCrtHGeDist(char* modPth, char* url);
void CCrtHGeDist_ctor(CCrtHGeDist* pThis, char* modPth, char* url);
void CCrtHGeDist_dtor(CCrtHGeDist* pThis);
void CCrtHGeDist_crtHGeDist(CCrtHGeDist* pThis, int populationSize, int numberOfSuccesses, int sampleSize, double p);
#endif
