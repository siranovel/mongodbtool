#ifndef _CCrtWblDist_H_
#define _CCrtWblDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtWblDist CCrtWblDist;

struct _CCrtWblDist
{
	void (*FP_crtWblDist)(CCrtWblDist* pThis, double alpha, double beta, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtWblDist* getCrtWblDist(char* modPth, char* url);
void CCrtWblDist_ctor(CCrtWblDist* pThis, char* modPth, char* url);
void CCrtWblDist_dtor(CCrtWblDist* pThis);
void CCrtWblDist_crtWblDist(CCrtWblDist* pThis, double alpha, double beta, double p);
#endif
