#include <stdio.h>
#include <assert.h>
#include "CCrtWblDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtWblDist(CCrtWblDist* pThis, double alpha, double beta, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double alpha = 0.0;
	double beta = 0.0;

	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &alpha);
	sscanf(argv[3], "%lf", &beta);
	char* url = (5 == argc) ? argv[4] : URL;
	CCrtWblDist* pThis = getCrtWblDist(updModPth, url);
	
	crtWblDist(pThis, alpha, beta, dt);
	CCrtWblDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <alpha> <beta> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\talpha > 0\n");
	printf("\tbeta > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtWblDist(CCrtWblDist* pThis, double alpha, double beta, double dt)
{
	CCrtWblDist_crtWblDist(pThis, alpha, beta, 0.05);
}
