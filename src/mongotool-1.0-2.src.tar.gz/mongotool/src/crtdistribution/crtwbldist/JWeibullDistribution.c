#include <stdio.h>
#include <assert.h>
#include "JWeibullDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jobject doNewWeibullDistribution(JNIEnv* env, jobject emptyM, jdouble alpha, jdouble beta);
static jdouble JWeibullDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject weidistObj, jdouble p);
static JWeibullDistribution _jWeiDist = {
	.FP_inverseCumulativeProbability = JWeibullDistribution_doInverseCumulativeProbability,
};
jobject newWeibullDistribution(JNIEnv* env, jobject emptyM, jdouble alpha, jdouble beta)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewWeibullDistribution(env, emptyM, alpha, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JWeibullDistribution_inverseCumulativeProbability(JNIEnv* env, jobject weidistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != weidistObj);
	return _jWeiDist.FP_inverseCumulativeProbability(env, weidistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewWeibullDistribution(JNIEnv* env, jobject emptyM, jdouble alpha, jdouble beta)
{
	jvalue argValues[] = {
		[0] = { .d = alpha},
		[1] = { .d = beta},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,WEI_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JWeibullDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject weidistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, weidistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, weidistObj, mid, argValues);
}

