#include <stdio.h>
#include <assert.h>
#include "JSet.h"

static jobject JSet_doIterator(JNIEnv* env, jobject setObj);
static void JSet_doAdd(JNIEnv* env, jobject set, jobject e);
static JSet _jSet = {
	.FP_iterator = JSet_doIterator,
	.FP_add      = JSet_doAdd,
};
jobject newSet(JNIEnv* env)
{
	jclass clz = JClass_FindClass(env, "java/util/HashSet");
	return JClass_NewObjectA(env, clz, "()V", NULL);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JSet_iterator(JNIEnv* env, jobject setObj)
{
	assert(env != 0);
	assert(setObj != 0);
	return _jSet.FP_iterator(env, setObj);
}
void JSet_add(JNIEnv* env, jobject setObj, jobject e)
{
	assert(env != 0);
	assert(setObj != 0);
	assert(e != NULL);
	_jSet.FP_add(env, setObj, e);
}
/**************************************/
/* �������s��                         */
/**************************************/
/*
 * Set.iterator����
 */
static jobject JSet_doIterator(JNIEnv* env, jobject setObj)
{
	jmethodID mid = JClass_GetMethodID(
		env, JClass_GetObjectClass(env, setObj), "iterator", "()Ljava/util/Iterator;"
	);
	
	return JClass_CallObjectMethodA(env, setObj, mid, NULL);
}
static void JSet_doAdd(JNIEnv* env, jobject setObj, jobject e)
{
	assert(e != 0);
	jvalue argValues[] = {
		[0] = { .l = e},
    };
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, setObj), "add", "(Ljava/lang/Object;)Z");
	JClass_CallBooleanMethodA(env, setObj, mid, argValues);
}
