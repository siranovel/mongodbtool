#ifndef _CCrtLaDist_H_
#define _CCrtLaDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtLaDist CCrtLaDist;

struct _CCrtLaDist
{
	void (*FP_crtLaDist)(CCrtLaDist* pThis, double mu, double beta, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtLaDist* getCrtLaDist(char* modPth, char* url);
void CCrtLaDist_ctor(CCrtLaDist* pThis, char* modPth, char* url);
void CCrtLaDist_dtor(CCrtLaDist* pThis);
void CCrtLaDist_crtLaDist(CCrtLaDist* pThis, double mu, double beta, double p);
#endif
