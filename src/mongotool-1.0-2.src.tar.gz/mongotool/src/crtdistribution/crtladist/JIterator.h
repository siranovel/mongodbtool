#ifndef _JIterator_H_
#define _JIterator_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JIterator JIterator;

struct _JIterator
{
	jboolean (*FP_hasNext)(JNIEnv* env, jobject iteObj);
	jobject (*FP_next)(JNIEnv* env, jobject iteObj);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jboolean JIterator_hasNext(JNIEnv* env, jobject iteObj);
jobject JIterator_next(JNIEnv* env, jobject iteObj);
#endif
