#ifndef _CCrtLeDist_H_
#define _CCrtLeDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtLeDist CCrtLeDist;

struct _CCrtLeDist
{
	void (*FP_crtLeDist)(CCrtLeDist* pThis, double mu, double c, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtLeDist* getCCrtLeDist(char* modPth, char* url);
void CCrtLeDist_ctor(CCrtLeDist* pThis, char* modPth, char* url);
void CCrtLeDist_dtor(CCrtLeDist* pThis);
void CCrtLeDist_crtLeDist(CCrtLeDist* pThis, double mu, double c, double p);
#endif
