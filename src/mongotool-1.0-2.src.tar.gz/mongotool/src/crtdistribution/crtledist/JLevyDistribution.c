#include <stdio.h>
#include <assert.h>
#include "JLevyDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewLevyDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble c);
static jdouble JLevyDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ledistObj, jdouble p);
static JLevyDistribution _jLeDist = {
	.FP_inverseCumulativeProbability = JLevyDistribution_doInverseCumulativeProbability,
};
jobject newLevyDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble c)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewLevyDistribution(env, emptyM, mu, c);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLevyDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ledistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != ledistObj);
	return _jLeDist.FP_inverseCumulativeProbability(env, ledistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLevyDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble c)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = c},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LE_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLevyDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ledistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, ledistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, ledistObj, mid, argValues);
}
