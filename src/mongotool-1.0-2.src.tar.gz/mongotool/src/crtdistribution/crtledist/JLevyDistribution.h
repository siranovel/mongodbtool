#ifndef _JLevyDistribution_H_
#define _JLevyDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLevyDistribution JLevyDistribution;

struct _JLevyDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject ledistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define LE_DIST "org.apache.commons.math3.distribution.LevyDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newLevyDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble c);
jdouble JLevyDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ledistObj, jdouble p);
#endif
