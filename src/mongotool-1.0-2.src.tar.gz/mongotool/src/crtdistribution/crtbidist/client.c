#include <stdio.h>
#include <assert.h>
#include "CCrtBiDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtBiDist(CCrtBiDist* pThis, int trials, double mu, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	int trials;
	double mu;
	
	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &trials);
	sscanf(argv[3], "%lf", &mu);
	char* url = (5 == argc) ? argv[4] : URL;
	CCrtBiDist* pThis = getCCrtBiDist(updModPth, url);
	
	crtBiDist(pThis, trials, mu, dt);
	CCrtBiDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <trials> <mu> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\ttrials > 0\n");
	printf("\tmu > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtBiDist(CCrtBiDist* pThis, int trials, double mu, double dt)
{
	int i;
	
	for (i = 0; i < trials; i++) {
		CCrtBiDist_crtBiDist(pThis, i, mu, 0.05);
	}
}
