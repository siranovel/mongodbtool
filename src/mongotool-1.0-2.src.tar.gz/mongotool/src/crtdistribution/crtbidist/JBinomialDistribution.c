#include <stdio.h>
#include <assert.h>
#include "JBinomialDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewBinomialDistribution(JNIEnv* env, jobject emptyM, int trials, double p);
static jint JBinomialDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject biDistObj, jdouble p);
static JBinomialDistribution _jBiDist = {
	.FP_inverseCumulativeProbability = JBinomialDistribution_doInverseCumulativeProbability,
};
jobject newBinomialDistribution(JNIEnv* env, jobject emptyM, int trials, double mu)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewBinomialDistribution(env, emptyM, trials, mu);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jint JBinomialDistribution_inverseCumulativeProbability(JNIEnv* env, jobject biDistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != biDistObj);
	return _jBiDist.FP_inverseCumulativeProbability(env, biDistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewBinomialDistribution(JNIEnv* env, jobject emptyM, int trials, double mu)
{
	jvalue argValues[] = {
		[0] = { .i = trials},
		[1] = { .d = mu},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,BI_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
}
static jint JBinomialDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject biDistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, biDistObj), "inverseCumulativeProbability", "(D)I");
	return JClass_CallIntMethodA(env, biDistObj, mid, argValues);
}
