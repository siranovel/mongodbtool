#ifndef _CCrtTDist_H_
#define _CCrtTDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtTDist CCrtTDist;

struct _CCrtTDist
{
	void (*FP_crtTInv)(CCrtTDist* pThis, double df, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtTDist* getCrtTDist(char* modPth, char* url);
void CCrtTDist_ctor(CCrtTDist* pThis, char* modPth, char* url);
void CCrtTDist_dtor(CCrtTDist* pThis);
void CCrtTDist_crtTInv(CCrtTDist* pThis, double df, double p);
#endif
