#ifndef _JTDistribution_H_
#define _JTDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JTDistribution JTDistribution;

struct _JTDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject tdistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define T_DIST "org.apache.commons.math3.distribution.TDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newTDistribution(JNIEnv* env, jobject emptyM, jdouble df);
jdouble JTDistribution_inverseCumulativeProbability(JNIEnv* env, jobject tdistObj, double p);
#endif
