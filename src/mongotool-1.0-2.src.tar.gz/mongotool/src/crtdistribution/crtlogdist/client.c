#include <stdio.h>
#include <assert.h>
#include "CCrtLogDist.h"


#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtLogDist(CCrtLogDist* pThis, double mu, double s, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double mu;
	double s;
	
	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &s);
	char* url = (5 == argc) ? argv[4] : URL;
	CCrtLogDist* pThis = getCrtLogDist(updModPth, url);
	
	crtLogDist(pThis, mu, s, dt);
	CCrtLogDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <mu> <s> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmu > 0\n");
	printf("\ts > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtLogDist(CCrtLogDist* pThis, double mu, double s, double dt)
{
	CCrtLogDist_crtLogDist(pThis, mu, s, 0.05);
}
