#include <stdio.h>
#include <assert.h>
#include "JLogisticDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jobject doNewLogisticDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble s);
static jdouble JLogisticDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ledistObj, jdouble p);
static JLogisticDistribution _jLogDist = {
	.FP_inverseCumulativeProbability = JLogisticDistribution_doInverseCumulativeProbability,
};
jobject newLogisticDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble s)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewLogisticDistribution(env, emptyM, mu, s);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLogisticDistribution_inverseCumulativeProbability(JNIEnv* env, jobject logdistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != logdistObj);
	return _jLogDist.FP_inverseCumulativeProbability(env, logdistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLogisticDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble s)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = s},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LOG_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLogisticDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject logdistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, logdistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, logdistObj, mid, argValues);
}
