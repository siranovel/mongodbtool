#include <stdio.h>
#include <assert.h>
#include "JNakagamiDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jobject doNewNakagamiDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble omega);
static jdouble JNakagamiDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ngDistObj, jdouble p);
static JNakagamiDistribution _jNgDist = {
	.FP_inverseCumulativeProbability = JNakagamiDistribution_doInverseCumulativeProbability,
};
jobject newNakagamiDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble omega)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewNakagamiDistribution(env, emptyM, mu, omega);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JNakagamiDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ngDistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != ngDistObj);
	return _jNgDist.FP_inverseCumulativeProbability(env, ngDistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNakagamiDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble omega)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = omega},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NG_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JNakagamiDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ngDistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, ngDistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, ngDistObj, mid, argValues);
}
