#ifndef _CCrtNGDist_H_
#define _CCrtNGDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtNGDist CCrtNGDist;

struct _CCrtNGDist
{
	void (*FP_crtNGDist)(CCrtNGDist* pThis, double mu, double omega, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtNGDist* getCrtNGDist(char* modPth, char* url);
void CCrtNGDist_ctor(CCrtNGDist* pThis, char* modPth, char* url);
void CCrtNGDist_dtor(CCrtNGDist* pThis);
void CCrtNGDist_crtNGDist(CCrtNGDist* pThis, double mu, double omega, double p);
#endif
