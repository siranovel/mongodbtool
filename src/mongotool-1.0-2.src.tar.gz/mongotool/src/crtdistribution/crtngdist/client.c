#include <stdio.h>
#include <assert.h>
#include "CCrtNGDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtNGDist(CCrtNGDist* pThis, double mu, double omega, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double mu = 0.0;
	double omega = 0.0;

	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &omega);
	char* url = (5 == argc) ? argv[4] : URL;
	CCrtNGDist* pThis = getCrtNGDist(updModPth, url);
	
	crtNGDist(pThis, mu, omega, dt);
	CCrtNGDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <mu> <omega> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmu > 0\n");
	printf("\tomega > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtNGDist(CCrtNGDist* pThis, double mu, double omega, double dt)
{
	CCrtNGDist_crtNGDist(pThis, mu, omega, 0.05);
}
