#ifndef _JNakagamiDistribution_H_
#define _JNakagamiDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JNakagamiDistribution JNakagamiDistribution;

struct _JNakagamiDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject ngDistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NG_DIST "org.apache.commons.math3.distribution.NakagamiDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNakagamiDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble omega);
jdouble JNakagamiDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ngDistObj, jdouble p);
#endif
