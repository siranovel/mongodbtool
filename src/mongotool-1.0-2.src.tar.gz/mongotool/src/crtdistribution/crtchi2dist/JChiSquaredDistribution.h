#ifndef _JChiSquaredDistribution_H_
#define _JChiSquaredDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JChiSquaredDistribution JChiSquaredDistribution;

struct _JChiSquaredDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject chi2distObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CHI2_DIST "org.apache.commons.math3.distribution.ChiSquaredDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newChiSquaredDistribution(JNIEnv* env, jobject emptyM, jdouble df);
jdouble JChiSquaredDistribution_inverseCumulativeProbability(JNIEnv* env, jobject chi2distObj, jdouble p);
#endif
