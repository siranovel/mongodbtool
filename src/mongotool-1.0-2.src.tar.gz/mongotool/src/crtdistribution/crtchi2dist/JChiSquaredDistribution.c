#include <stdio.h>
#include <assert.h>
#include "JChiSquaredDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewChiSquaredDistribution(JNIEnv* env, jobject emptyM, jdouble df);
static jdouble JChiSquaredDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject chi2distObj, jdouble p);
static JChiSquaredDistribution _jChi2Dist = {
	.FP_inverseCumulativeProbability = JChiSquaredDistribution_doInverseCumulativeProbability,
};
jobject newChiSquaredDistribution(JNIEnv* env, jobject emptyM, jdouble df)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewChiSquaredDistribution(env, emptyM, df);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JChiSquaredDistribution_inverseCumulativeProbability(JNIEnv* env, jobject chi2distObj, jdouble p)
{
	assert(0 != env);
	assert(0 != chi2distObj);
	return _jChi2Dist.FP_inverseCumulativeProbability(env, chi2distObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewChiSquaredDistribution(JNIEnv* env, jobject emptyM, jdouble df)
{
	jvalue argValues[] = {
		[0] = { .d = df},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,CHI2_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JChiSquaredDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject chi2distObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chi2distObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, chi2distObj, mid, argValues);
}
