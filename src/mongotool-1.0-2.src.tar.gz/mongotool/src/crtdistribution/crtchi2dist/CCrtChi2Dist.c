#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CCrtChi2Dist.h"
#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JChiSquaredDistribution.h"

static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static mongoc_collection_t* _coll = 0;
static mongoc_client_t* _client = 0;
static jobject _emptyM = 0;
static void CCrtChi2Dist_doCrtChi2Dist(CCrtChi2Dist* pThis, double df, double p);
static int64_t cntChi2Dist(double df, double p);
static void insChi2Dist(double df, double p);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);
static CCrtChi2Dist _cCrtChi2Dist = {
	.FP_crtChi2Dist = CCrtChi2Dist_doCrtChi2Dist,
};
CCrtChi2Dist* getCrtChi2Dist(char* modPth, char* url)
{
	CCrtChi2Dist_ctor(&_cCrtChi2Dist, modPth, url);
	return &_cCrtChi2Dist;
}
void CCrtChi2Dist_ctor(CCrtChi2Dist* pThis, char* modPth, char* url)
{
	init();
	updModPth(modPth);
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "crtchi2dist");
    _coll = mongoc_client_get_collection(_client, "distdb", "chi2inv");
}
void CCrtChi2Dist_dtor(CCrtChi2Dist* pThis)
{
	end();
	if (_coll)
	    mongoc_collection_destroy(_coll);
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CCrtChi2Dist_crtChi2Dist(CCrtChi2Dist* pThis, double df, double p)
{
	assert(0 != pThis);
	assert(_env != 0);
	assert(_emptyM != 0);
	pThis->FP_crtChi2Dist(pThis, df, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CCrtChi2Dist_doCrtChi2Dist(CCrtChi2Dist* pThis, double df, double p)
{
	double pp = (int)(p * 1000) / 1000.0;
	
	if (0 == cntChi2Dist(df, pp)) {
		insChi2Dist(df, pp);
	}
}
static int64_t cntChi2Dist(double df, double p)
{
    bson_t* doc;
    int64_t count;
	bson_t  reply;
    bson_error_t error;

	doc = bson_new();
	BSON_APPEND_DOUBLE(doc, "df", df);
	BSON_APPEND_DOUBLE(doc, "p", p);
	count = mongoc_collection_count_documents(_coll, doc, NULL, NULL, &reply, &error);
	if (count < 0) {
		fprintf(stderr, "%s\n", error.message);
	}
	
	bson_destroy(doc);
	return count;
	
}
static void insChi2Dist(double df, double p)
{
	jobject chi2distObj = newChiSquaredDistribution(_env, _emptyM, df);
	double chi = JChiSquaredDistribution_inverseCumulativeProbability(_env, chi2distObj, 1.0 - p);
    bson_error_t error;
    bson_oid_t oid;
    bson_t* doc;
	
	doc = bson_new();
	bson_oid_init(&oid, NULL);
	BSON_APPEND_OID(doc, "_id", &oid);
	BSON_APPEND_DOUBLE(doc, "df", df);
	BSON_APPEND_DOUBLE(doc, "p", p);
	BSON_APPEND_DOUBLE(doc, "chi", chi);
	
	if (!mongoc_collection_insert_one(_coll, doc, NULL, NULL, &error)) {
		fprintf(stderr, "%s\n", error.message);
	}
	bson_destroy(doc);
}

static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	,{.optionString = "-XX:+UseJVMCICompiler", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, modPth);
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	_emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
