#include <stdio.h>
#include <assert.h>
#include "CCrtChi2Dist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtChi2Dist(CCrtChi2Dist*pThis, double df, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double df = 0.0;

	if (3 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &df);
	char* url = (4 == argc) ? argv[3] : URL;
	CCrtChi2Dist* pThis = getCrtChi2Dist(updModPth, url);
	
	crtChi2Dist(pThis, df, dt);
	CCrtChi2Dist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <degreesOfFreedom> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tdf > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtChi2Dist(CCrtChi2Dist*pThis, double df, double dt)
{
	int i;
	
	for (i = 0; i < df; i++) {
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.995);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.990);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.975);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.950);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.050);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.025);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.010);
		CCrtChi2Dist_crtChi2Dist(pThis, i + 1, 0.005);
	}
}
