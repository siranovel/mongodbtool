#include <stdio.h>
#include <assert.h>
#include "CCrtPoDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtPoDist(CCrtPoDist* pThis, double lambda, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double lambda;
	
	if (3 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &lambda);
	char* url = (4 == argc) ? argv[3] : URL;
	CCrtPoDist* pThis = getCCrtPoDist(updModPth, url);
	
	crtPoDist(pThis, lambda, dt);
	CCrtPoDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <lambda> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tlambda > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtPoDist(CCrtPoDist* pThis, double lambda, double dt)
{
	CCrtPoDist_crtPoDist(pThis, lambda, 0.05);
}
