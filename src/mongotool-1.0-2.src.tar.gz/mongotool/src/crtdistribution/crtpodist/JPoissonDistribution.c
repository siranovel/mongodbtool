#include <stdio.h>
#include <assert.h>
#include "JPoissonDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewPoissonDistribution(JNIEnv* env, jobject emptyM, double lambda);
static jint JPoissonDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject poDistObj, jdouble p);
static jdouble JPoissonDistribution_doNormalApproximateProbability(JNIEnv* env, jobject poDistObj, jint x);
static JPoissonDistribution _jPoDist = {
	.FP_inverseCumulativeProbability = JPoissonDistribution_doInverseCumulativeProbability,
	.FP_normalApproximateProbability = JPoissonDistribution_doNormalApproximateProbability,
};
jobject newPoissonDistribution(JNIEnv* env, jobject emptyM, double lambda)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewPoissonDistribution(env, emptyM, lambda);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jint JPoissonDistribution_inverseCumulativeProbability(JNIEnv* env, jobject poDistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != poDistObj);
	return _jPoDist.FP_inverseCumulativeProbability(env, poDistObj, p);
}
jdouble JPoissonDistribution_normalApproximateProbability(JNIEnv* env, jobject poDistObj, jint x)
{
	assert(0 != env);
	assert(0 != poDistObj);
	return _jPoDist.FP_normalApproximateProbability(env, poDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewPoissonDistribution(JNIEnv* env, jobject emptyM, double lambda)
{
	jvalue argValues[] = {
		[0] = { .d = lambda},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,PO_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jint JPoissonDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject poDistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, poDistObj), "inverseCumulativeProbability", "(D)I");
	return JClass_CallIntMethodA(env, poDistObj, mid, argValues);
}
static jdouble JPoissonDistribution_doNormalApproximateProbability(JNIEnv* env, jobject poDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, poDistObj), "normalApproximateProbability", "(I)D");
	return JClass_CallDoubleMethodA(env, poDistObj, mid, argValues);
}

