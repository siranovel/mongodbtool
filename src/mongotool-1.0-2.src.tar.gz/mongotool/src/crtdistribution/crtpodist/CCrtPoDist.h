#ifndef _CCrtPoDist_H_
#define _CCrtPoDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtPoDist CCrtPoDist;

struct _CCrtPoDist
{
	void (*FP_crtPoDist)(CCrtPoDist* pThis, double lambda, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtPoDist* getCCrtPoDist(char* modPth, char* url);
void CCrtPoDist_ctor(CCrtPoDist* pThis, char* modPth, char* url);
void CCrtPoDist_dtor(CCrtPoDist* pThis);
void CCrtPoDist_crtPoDist(CCrtPoDist* pThis, double lambda, double p);

#endif
