#ifndef _JPoissonDistribution_H_
#define _JPoissonDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPoissonDistribution JPoissonDistribution;

struct _JPoissonDistribution
{
	jint    (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject poDistObj, jdouble p);
	jdouble (*FP_normalApproximateProbability)(JNIEnv* env, jobject poDistObj, jint x);     // ���K�ߎ��m��
};
/**************************************/
/* define�錾                         */
/**************************************/
#define PO_DIST "org.apache.commons.math3.distribution.PoissonDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newPoissonDistribution(JNIEnv* env, jobject emptyM, double lambda);
jint JPoissonDistribution_inverseCumulativeProbability(JNIEnv* env, jobject poDistObj, jdouble p);
jdouble JPoissonDistribution_normalApproximateProbability(JNIEnv* env, jobject poDistObj, jint x);
#endif
