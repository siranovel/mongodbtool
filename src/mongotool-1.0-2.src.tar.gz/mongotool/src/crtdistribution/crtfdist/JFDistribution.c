#include <stdio.h>
#include <assert.h>
#include "JFDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jobject doNewFDistribution(JNIEnv* env, jobject emptyM, jdouble nf, jdouble df);
static jdouble JFDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject fdistObj, double p);
static JFDistribution _jFDist = {
	.FP_inverseCumulativeProbability = JFDistribution_doInverseCumulativeProbability,
};
jobject newFDistribution(JNIEnv* env, jobject emptyM, jdouble nf, jdouble df)
{
	assert(env != 0);
	assert(emptyM != 0);
	
	return doNewFDistribution(env, emptyM, nf, df);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JFDistribution_inverseCumulativeProbability(JNIEnv* env, jobject fdistObj, double p)
{
	assert(env != 0);
	assert(fdistObj != 0);
	return _jFDist.FP_inverseCumulativeProbability(env, fdistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewFDistribution(JNIEnv* env, jobject emptyM, jdouble nf, jdouble df)
{
	jvalue argValues[] = {
		[0] = { .d = nf},
		[1] = { .d = df},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,F_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JFDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject fdistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, fdistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, fdistObj, mid, argValues);
}
