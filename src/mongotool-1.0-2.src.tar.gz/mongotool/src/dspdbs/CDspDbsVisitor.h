#ifndef _CDspDbsVisitor_H_
#define _CDspDbsVisitor_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDbsVisitor CDspDbsVisitor;
typedef struct _CDspDbs CDspDbs;

struct _CDspDbsVisitor
{
	void (*FP_visitDspDbs)(CDspDbsVisitor* pThis, CDspDbs* dspDbs);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDbsVisitor* getDspDbsVisitor(char* url);
void CDspDbsVisitor_ctor(CDspDbsVisitor* pThis, char* url);
void CDspDbsVisitor_dtor(CDspDbsVisitor* pThis);
void CDspDbsVisitor_visitDspDbs(CDspDbsVisitor* pThis, CDspDbs* dspDbs);
#endif
