#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CDspDbsVisitor.h"
#include "CDspDbs.h"

static mongoc_client_t* _client = 0;
static void CDspDbsVisitor_doVisitDspDbs(CDspDbsVisitor* pThis, CDspDbs* dspDbs);
static CDspDbsVisitor _visit = {
	.FP_visitDspDbs = CDspDbsVisitor_doVisitDspDbs,
};
CDspDbsVisitor* getDspDbsVisitor(char* url)
{
	CDspDbsVisitor_ctor(&_visit, url);
	return &_visit;
}
void CDspDbsVisitor_ctor(CDspDbsVisitor* pThis, char* url)
{
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "dspdbs");
}
void CDspDbsVisitor_dtor(CDspDbsVisitor* pThis)
{
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDbsVisitor_visitDspDbs(CDspDbsVisitor* pThis, CDspDbs* dspDbs)
{
	assert(pThis != 0);
	assert(dspDbs != 0);
	pThis->FP_visitDspDbs(pThis, dspDbs);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDbsVisitor_doVisitDspDbs(CDspDbsVisitor* pThis, CDspDbs* dspDbs)
{
	CDspDbs* w = dspDbs;
    bson_error_t error;
	char** names = 0;
	int i = 0;
	
	names = mongoc_client_get_database_names_with_opts(_client, NULL, &error);
	for (i = 0; names[i] != 0; i++) {
		w->next = getDspDbs();
		w->dbName = names[i];
		w = w->next;
	}
}
