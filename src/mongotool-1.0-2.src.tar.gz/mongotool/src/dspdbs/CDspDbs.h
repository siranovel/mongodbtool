#ifndef _CDspDbs_H_
#define _CDspDbs_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspDbs CDspDbs;
typedef struct _CDspDbsVisitor CDspDbsVisitor;

struct _CDspDbs
{
	CDspDbs* next;
	char* dbName;
	void (*FP_accept)(CDspDbs* pThis, CDspDbsVisitor* visit);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspDbs* getDspDbs();
void CDspDbs_ctor(CDspDbs* pThis);
void CDspDbs_dtor(CDspDbs* pThis);
void CDspDbs_accept(CDspDbs* pThis, CDspDbsVisitor* visit);
#endif
