#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CDspDbs.h"
#include "CDspDbsVisitor.h"

static void CDspDbs_setFuncPoint(CDspDbs* pThis);
static void CDspDbs_doAccept(CDspDbs* pThis, CDspDbsVisitor* visit);
CDspDbs* getDspDbs()
{
	CDspDbs* pThis = malloc(sizeof(CDspDbs));
	
	CDspDbs_ctor(pThis);
	return pThis;
}
void CDspDbs_ctor(CDspDbs* pThis)
{
	CDspDbs_setFuncPoint(pThis);
	pThis->next = 0;
}
static void CDspDbs_setFuncPoint(CDspDbs* pThis)
{
	pThis->FP_accept = CDspDbs_doAccept;
}
void CDspDbs_dtor(CDspDbs* pThis)
{
	free(pThis);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspDbs_accept(CDspDbs* pThis, CDspDbsVisitor* visit)
{
	assert(pThis != 0);
	pThis->FP_accept(pThis, visit);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDspDbs_doAccept(CDspDbs* pThis, CDspDbsVisitor* visit)
{
	CDspDbsVisitor_visitDspDbs(visit, pThis);
}
