#include <stdio.h>
#include <assert.h>
#include "CDspDbs.h"
#include "CDspDbsVisitor.h"


#define URL "mongodb://localhost:27017"
static void dspDbs(CDspDbs* pThis, char* url);
int main(int argc, char* argv[])
{
	CDspDbs* pThis = getDspDbs();
	char* url = (2 == argc) ? argv[1] : URL;
	
	dspDbs(pThis, url);
	CDspDbs_dtor(pThis);
	return 0;
}
static void dspDbs(CDspDbs* pThis, char* url)
{
	CDspDbsVisitor* visit = getDspDbsVisitor(url);
	
	CDspDbs_accept(pThis, visit);
	while(0 != pThis->next) {
		printf("%s\n", pThis->dbName);
		pThis = pThis->next;
	}
	CDspDbsVisitor_dtor(visit);
}
