#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "CDropDistDB.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* tblName = argv[1];
	char* url = (3 == argc) ? argv[2] : URL;
	CDropDistDB* pThis = getDropDistDB(url);
	
	if (0 == strcmp("all", tblName)) {
		CDropDistDB_dropDistDBs(pThis);
	} else {
		CDropDistDB_dropDistDB(pThis, tblName);
	}
	CDropDistDB_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <tableName> | <mongodbURL>\n", exeNm);
	printf("\n");
	printf("\tmongodbURL	default: %s\n", url);
	printf("\tテーブル名は、dspdistdbsで確認。\n");
}
