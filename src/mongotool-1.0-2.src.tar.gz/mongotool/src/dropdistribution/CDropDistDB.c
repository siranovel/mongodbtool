#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <bson/bson.h>
#include <mongoc/mongoc.h>

#include "CDropDistDB.h"

static mongoc_client_t* _client = 0;
static void CDropDistDB_doDropDistDB(CDropDistDB* pThis, char* tblName);
static void CDropDistDB_doDropDistDBs(CDropDistDB* pThis);
static CDropDistDB _cDropDistDB = {
	.FP_dropDistDB = CDropDistDB_doDropDistDB,
	.FP_dropDistDBs = CDropDistDB_doDropDistDBs,
};
CDropDistDB* getDropDistDB(char* url)
{
	CDropDistDB_ctor(&_cDropDistDB, url);
	return &_cDropDistDB;
}
void CDropDistDB_ctor(CDropDistDB* pThis, char* url)
{
    mongoc_init();
    _client = mongoc_client_new(url);
    mongoc_client_set_appname(_client, "dropdistdb");
}
void CDropDistDB_dtor(CDropDistDB* pThis)
{
	if (_client)
	    mongoc_client_destroy(_client);
    mongoc_cleanup();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDropDistDB_dropDistDB(CDropDistDB* pThis, char* tblName)
{
	assert(pThis != 0);
	assert(_client != 0);
	pThis->FP_dropDistDB(pThis, tblName);
}
void CDropDistDB_dropDistDBs(CDropDistDB* pThis)
{
	assert(pThis != 0);
	assert(_client != 0);
	pThis->FP_dropDistDBs(pThis);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void CDropDistDB_doDropDistDB(CDropDistDB* pThis, char* tblName)
{
    bson_error_t error;
	mongoc_database_t* db = mongoc_client_get_database(_client, "distdb");
	
	if (!mongoc_database_has_collection(db, tblName, &error)) {
		fprintf(stderr, "%s is not exist\n", tblName);
		return;
	}
	
    mongoc_collection_t* coll = mongoc_database_get_collection(db, tblName);
	if (!mongoc_collection_drop(coll, &error)) {
		fprintf(stderr, "%s\n", error.message);
	}
	if (coll)
	    mongoc_collection_destroy(coll);
}
static void CDropDistDB_doDropDistDBs(CDropDistDB* pThis)
{
	mongoc_database_t* db = mongoc_client_get_database(_client, "distdb");
    bson_error_t error;
	char** names = 0;
	int i = 0;

	names = mongoc_database_get_collection_names_with_opts(db, NULL, &error);
	for (i = 0; names[i] != 0; i++) {
		CDropDistDB_dropDistDB(pThis, names[i]);
	}
	
}
