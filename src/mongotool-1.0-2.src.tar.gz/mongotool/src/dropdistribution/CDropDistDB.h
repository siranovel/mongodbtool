#ifndef _CDropDistDB_H_
#define _CDropDistDB_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDropDistDB CDropDistDB;

struct _CDropDistDB
{
	void (*FP_dropDistDB)(CDropDistDB* pThis, char* tblName);
	void (*FP_dropDistDBs)(CDropDistDB* pThis);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDropDistDB* getDropDistDB(char* url);
void CDropDistDB_ctor(CDropDistDB* pThis, char* url);
void CDropDistDB_dtor(CDropDistDB* pThis);
void CDropDistDB_dropDistDB(CDropDistDB* pThis, char* tblName);
void CDropDistDB_dropDistDBs(CDropDistDB* pThis);
#endif
