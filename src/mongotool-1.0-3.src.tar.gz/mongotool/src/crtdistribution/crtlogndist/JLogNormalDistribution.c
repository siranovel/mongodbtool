#include <stdio.h>
#include <assert.h>
#include "JLogNormalDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewLogNormalDistribution(JNIEnv* env, jobject emptyM);
static double JLogNormalDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject logndistObj, double p);
static JLogNormalDistribution _jLogNDist = {
	.FP_inverseCumulativeProbability = JLogNormalDistribution_doInverseCumulativeProbability,
};
jobject newLogNormalDistribution(JNIEnv* env, jobject emptyM)
{
	assert(env != 0);
	assert(emptyM != 0);
	return doNewLogNormalDistribution(env, emptyM);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
double JLogNormalDistribution_inverseCumulativeProbability(JNIEnv* env, jobject logndistObj, double p)
{
	assert(env != 0);
	assert(logndistObj != 0);
	return _jLogNDist.FP_inverseCumulativeProbability(env, logndistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLogNormalDistribution(JNIEnv* env, jobject emptyM)
{
	jvalue argValues[] = {
		[0] = { .d = 0},
		[1] = { .d = 1},
	};
	
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LOG_NORM_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static double JLogNormalDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject logndistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, logndistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, logndistObj, mid, argValues);
}
