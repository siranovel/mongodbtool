#ifndef _JLogNormalDistribution_H_
#define _JLogNormalDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLogNormalDistribution JLogNormalDistribution;

struct _JLogNormalDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject logndistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define LOG_NORM_DIST "org.apache.commons.math3.distribution.LogNormalDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newLogNormalDistribution(JNIEnv* env, jobject emptyM);
double JLogNormalDistribution_inverseCumulativeProbability(JNIEnv* env, jobject logndistObj, double p);
#endif
