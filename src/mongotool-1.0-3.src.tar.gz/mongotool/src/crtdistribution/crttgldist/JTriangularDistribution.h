#ifndef _JTriangularDistribution_H_
#define _JTriangularDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JTriangularDistribution JTriangularDistribution;

struct _JTriangularDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject tglDistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define TGL_DIST "org.apache.commons.math3.distribution.TriangularDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newTriangularDistribution(JNIEnv* env, jobject emptyM, jdouble a, jdouble c, jdouble b);
jdouble JTriangularDistribution_inverseCumulativeProbability(JNIEnv* env, jobject tglDistObj, jdouble p);

#endif
