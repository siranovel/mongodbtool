#include <stdio.h>
#include <assert.h>
#include "JTDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jdouble JTDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject tdistObj, double p);
static JTDistribution _jTDist = {
	.FP_inverseCumulativeProbability = JTDistribution_doInverseCumulativeProbability,
};
jobject newTDistribution(JNIEnv* env, jobject emptyM, jdouble df)
{
	jvalue argValues[] = {
		[0] = { .d = df},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,T_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JTDistribution_inverseCumulativeProbability(JNIEnv* env, jobject tdistObj, double p)
{
	assert(env != 0);
	assert(tdistObj != 0);
	return _jTDist.FP_inverseCumulativeProbability(env, tdistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jdouble JTDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject tdistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, tdistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, tdistObj, mid, argValues);
}
