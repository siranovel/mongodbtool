#include <stdio.h>
#include <assert.h>
#include "JLaplaceDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewLaplaceDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta);
static jdouble JLaplaceDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble p);
static JLaplaceDistribution _jLaDist = {
	.FP_inverseCumulativeProbability = JLaplaceDistribution_doInverseCumulativeProbability,
};
jobject newLaplaceDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewLaplaceDistribution(env, emptyM, mu, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLaplaceDistribution_inverseCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != laDistObj);
	return _jLaDist.FP_inverseCumulativeProbability(env, laDistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLaplaceDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = beta},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LA_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLaplaceDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, laDistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, laDistObj, mid, argValues);
}

