#ifndef _JLaplaceDistribution_H_
#define _JLaplaceDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLaplaceDistribution JLaplaceDistribution;

struct _JLaplaceDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject laDistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define LA_DIST "org.apache.commons.math3.distribution.LaplaceDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newLaplaceDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta);
jdouble JLaplaceDistribution_inverseCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble p);
#endif
