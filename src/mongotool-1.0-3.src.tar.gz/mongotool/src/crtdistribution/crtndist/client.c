#include <stdio.h>
#include <assert.h>
#include "CCrtNDist.h"


#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtNDist(CCrtNDist* pthis, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	
	if (2 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	char* url = (3 == argc) ? argv[2] : URL;
	CCrtNDist* pThis = getCrtNDist(updModPth, url);
	
	crtNDist(pThis, dt);
	CCrtNDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("%s <commons math3 Module Path> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtNDist(CCrtNDist* pthis, double dt)
{
	double p;
	
	for (p = 0.0; p < 1.0; p+=dt) {
		CCrtNDist_crtNormInv(pthis, p);
	}
}
