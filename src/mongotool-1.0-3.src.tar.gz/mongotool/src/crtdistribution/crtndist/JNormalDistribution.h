#ifndef _JNormalDistribution_H_
#define _JNormalDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JNormalDistribution JNormalDistribution;

struct _JNormalDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject ndistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NORM_DIST "org.apache.commons.math3.distribution.NormalDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNormalDistribution(JNIEnv* env, jobject emptyM);
jdouble JNormalDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ndistObj, double p);
#endif
