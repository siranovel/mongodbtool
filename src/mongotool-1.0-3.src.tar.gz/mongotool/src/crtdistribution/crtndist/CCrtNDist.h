#ifndef _CCrtNDist_H_
#define _CCrtNDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtNDist CCrtNDist;

struct _CCrtNDist
{
	void (*FP_crtNormInv)(CCrtNDist* pThis, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtNDist* getCrtNDist(char* modPth, char* url);
void CCrtNDist_ctor(CCrtNDist* pThis, char* modPth, char* url);
void CCrtNDist_dtor(CCrtNDist* pThis);
void CCrtNDist_crtNormInv(CCrtNDist* pThis, double p);
#endif
