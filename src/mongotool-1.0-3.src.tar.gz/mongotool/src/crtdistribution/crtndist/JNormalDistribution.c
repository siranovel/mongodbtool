#include <stdio.h>
#include <assert.h>
#include "JNormalDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"


static jobject doNewNormalDistribution(JNIEnv* env, jobject emptyM);
static jdouble JNormalDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ndistObj, double p);
static JNormalDistribution _jNormDist = {
	.FP_inverseCumulativeProbability = JNormalDistribution_doInverseCumulativeProbability,
};
jobject newNormalDistribution(JNIEnv* env, jobject emptyM)
{
	return doNewNormalDistribution(env, emptyM);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JNormalDistribution_inverseCumulativeProbability(JNIEnv* env, jobject ndistObj, double p)
{
	assert(env != 0);
	assert(ndistObj != 0);
	return _jNormDist.FP_inverseCumulativeProbability(env, ndistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNormalDistribution(JNIEnv* env, jobject emptyM)
{
	jvalue argValues[] = {
		[0] = { .d = 0},
		[1] = { .d = 1},
	};
	
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NORM_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JNormalDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject ndistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, ndistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, ndistObj, mid, argValues);
	
}
