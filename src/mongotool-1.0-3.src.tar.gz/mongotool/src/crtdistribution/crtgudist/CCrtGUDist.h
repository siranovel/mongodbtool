#ifndef _CCrtGUDist_H_
#define _CCrtGUDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtGUDist CCrtGUDist;

struct _CCrtGUDist
{
	void (*FP_crtGUDist)(CCrtGUDist* pThis, double mu, double beta, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtGUDist* getCrtGUDist(char* modPth, char* url);
void CCrtGUDist_ctor(CCrtGUDist* pThis, char* modPth, char* url);
void CCrtGUDist_dtor(CCrtGUDist* pThis);
void CCrtGUDist_crtGUDist(CCrtGUDist* pThis, double mu, double beta, double p);
#endif
