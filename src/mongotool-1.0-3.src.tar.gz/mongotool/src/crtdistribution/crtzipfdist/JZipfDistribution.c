#include <stdio.h>
#include <assert.h>
#include "JZipfDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewZipfDistribution(JNIEnv* env, jobject emptyM, jint nElm, jdouble exponent);
static jint JZipfDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject zipfdistObj, double p);
static JZipfDistribution _jZipfDist = {
	.FP_inverseCumulativeProbability = JZipfDistribution_doInverseCumulativeProbability,
};
jobject newZipfDistribution(JNIEnv* env, jobject emptyM, jint nElm, jdouble exponent)
{
	assert(env != 0);
	assert(emptyM != 0);
	return doNewZipfDistribution(env, emptyM, nElm, exponent);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jint JZipfDistribution_inverseCumulativeProbability(JNIEnv* env, jobject zipfdistObj, double p)
{
	assert(env != 0);
	assert(zipfdistObj != 0);
	return _jZipfDist.FP_inverseCumulativeProbability(env, zipfdistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewZipfDistribution(JNIEnv* env, jobject emptyM, jint nElm, jdouble exponent)
{
	jvalue argValues[] = {
		[0] = { .i = nElm},
		[1] = { .d = exponent},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,Zipf_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
	
}
static jint JZipfDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject zipfdistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, zipfdistObj), "inverseCumulativeProbability", "(D)I");
	return JClass_CallIntMethodA(env, zipfdistObj, mid, argValues);
}
