#include <stdio.h>
#include <assert.h>
#include "JGamma.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jdouble JGamma_doGamma(JNIEnv* env, jobject emptyM, jdouble x);
static JGamma _jGamma = {
	.FP_gamma = JGamma_doGamma
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGamma_gamma(JNIEnv* env, jobject emptyM, jdouble x)
{
	assert(0 != env);
	assert(0 != emptyM);
	return _jGamma.FP_gamma(env, emptyM, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jdouble JGamma_doGamma(JNIEnv* env, jobject emptyM, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GAMMA));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "gamma", "(D)D");
	
	return JClass_CallStaticDoubleMethodA(env, clz, mid, argValues);
}
