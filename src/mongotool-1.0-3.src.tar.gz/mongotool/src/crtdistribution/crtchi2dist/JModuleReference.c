#include <stdio.h>
#include <assert.h>
#include "JModuleReference.h"

static jobject JModuleReference_doDescriptor(JNIEnv *env, jobject mref);
static JModuleReference _jModulereference = {
	.FP_descriptor = JModuleReference_doDescriptor,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JModuleReference_descriptor(JNIEnv *env, jobject mref)
{
	assert(env != 0);
	return _jModulereference.FP_descriptor(env, mref);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JModuleReference_doDescriptor(JNIEnv *env, jobject mref)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, mref), "descriptor", "()Ljava/lang/module/ModuleDescriptor;");
	
	return JClass_CallObjectMethodA(env, mref, mid, NULL);
}
