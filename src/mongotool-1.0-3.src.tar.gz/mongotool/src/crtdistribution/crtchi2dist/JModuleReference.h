#ifndef _JModuleReference_H_
#define _JModuleReference_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JModuleReference JModuleReference;

struct _JModuleReference
{
	jobject (*FP_descriptor)(JNIEnv *env, jobject mref);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JModuleReference_descriptor(JNIEnv *env, jobject mref);
#endif
