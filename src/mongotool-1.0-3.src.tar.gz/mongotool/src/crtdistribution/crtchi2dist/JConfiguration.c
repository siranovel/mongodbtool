#include <stdio.h>
#include <assert.h>
#include "JConfiguration.h"

static jobject JConfiguration_doResolveAndBind(JNIEnv* env, jobject cf, jobject before, jobject after, jobject roots);
static jobject JConfiguration_doModules(JNIEnv* env, jobject cf);
static JConfiguration _jConfiguration = {
	.FP_resolveAndBind = JConfiguration_doResolveAndBind,
	.FP_modules = JConfiguration_doModules,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JConfiguration_resolveAndBind(JNIEnv* env, jobject cf, jobject before, jobject after, jobject roots)
{
	return _jConfiguration.FP_resolveAndBind(env, cf, before, after, roots);
}
jobject JConfiguration_modules(JNIEnv* env, jobject cf)
{
	return _jConfiguration.FP_modules(env, cf);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JConfiguration_doResolveAndBind(JNIEnv* env, jobject cf, jobject before, jobject after, jobject roots)
{
	assert(before != 0);
	assert(after != 0);
	assert(roots != 0);
	jvalue argValues[] = {
		[0] = { .l = before},
		[1] = { .l = after},
		[2] = { .l = roots},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, cf), "resolveAndBind", "(Ljava/lang/module/ModuleFinder;Ljava/lang/module/ModuleFinder;Ljava/util/Collection;)Ljava/lang/module/Configuration;");
	return JClass_CallObjectMethodA(env, cf, mid, argValues);
	
}
static jobject JConfiguration_doModules(JNIEnv* env, jobject cf)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, cf), "modules", "()Ljava/util/Set;");
	return JClass_CallObjectMethodA(env, cf, mid, NULL);
}
