#ifndef _CCrtChi2Dist_H_
#define _CCrtChi2Dist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtChi2Dist CCrtChi2Dist;

struct _CCrtChi2Dist
{
	void (*FP_crtChi2Dist)(CCrtChi2Dist* pThis, double df, double p);
};

/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtChi2Dist* getCrtChi2Dist(char* modPth, char* url);
void CCrtChi2Dist_ctor(CCrtChi2Dist* pThis, char* modPth, char* url);
void CCrtChi2Dist_dtor(CCrtChi2Dist* pThis);
void CCrtChi2Dist_crtChi2Dist(CCrtChi2Dist* pThis, double df, double p);
#endif
