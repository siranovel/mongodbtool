#ifndef _JModuleLayer_H_
#define _JModuleLayer_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JModuleLayer JModuleLayer;

struct _JModuleLayer
{
	jobject (*FP_boot)(JNIEnv* env);
	jobject (*FP_configuration)(JNIEnv* env, jobject layer);
	jobject (*FP_modules)(JNIEnv* env, jobject layer);
	jobject (*FP_defineModules)(JNIEnv* env, jobject layer, jobject cf, jobject clf);
	jobject (*FP_findModule)(JNIEnv* env, jobject layer, jstring name);
	jobject (*FP_findLoader)(JNIEnv* env, jobject layer, jstring name);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JModuleLayer_boot(JNIEnv* env);
jobject JModuleLayer_configuration(JNIEnv* env, jobject layer);
jobject JModuleLayer_modules(JNIEnv* env, jobject layer);
jobject JModuleLayer_defineModules(JNIEnv* env, jobject layer, jobject cf, jobject clf);
jobject JModuleLayer_findModule(JNIEnv* env, jobject layer, jstring name);
jobject JModuleLayer_findLoader(JNIEnv* env, jobject layer, jstring name);
#endif
