#include <stdio.h>
#include <assert.h>
#include "JIterator.h"

static jboolean JIterator_doHasNext(JNIEnv* env, jobject iteObj);
static jobject JIterator_doNext(JNIEnv* env, jobject iteObj);
static JIterator _jIterator = {
	.FP_hasNext = JIterator_doHasNext,
	.FP_next    = JIterator_doNext
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/*
 * Iterator.hasNext����
 */
jboolean JIterator_hasNext(JNIEnv* env, jobject iteObj)
{
	assert(env != NULL);
	assert(iteObj != NULL);
	return _jIterator.FP_hasNext(env, iteObj);
}
/*
 * Iterator.next����
 */
jobject JIterator_next(JNIEnv* env, jobject iteObj)
{
	assert(env != NULL);
	assert(iteObj != NULL);
	return _jIterator.FP_next(env, iteObj);
}
/**************************************/
/* �������s��                         */
/**************************************/
/*
 * Iterator.hasNext����
 */
static jboolean JIterator_doHasNext(JNIEnv* env, jobject iteObj)
{
	jmethodID mid = JClass_GetMethodID(
		env, JClass_GetObjectClass(env, iteObj), "hasNext", "()Z"
	);
	
	return JClass_CallBooleanMethodA(env, iteObj, mid, NULL);
}
/*
 * Iterator.next����
 */
static jobject JIterator_doNext(JNIEnv* env, jobject iteObj)
{
	jmethodID mid = JClass_GetMethodID(
		env, JClass_GetObjectClass(env, iteObj), "next", "()Ljava/lang/Object;"
	);
	return JClass_CallObjectMethodA(env, iteObj, mid, NULL);
}
