#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <iconv.h>
#include "JClass.h"

static jclass JClass_doFindClass(JNIEnv* env, char* className);
static jmethodID JClass_doGetMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig);
static jmethodID JClass_doGetStaticMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig);
static jclass JClass_doGetObjectClass(JNIEnv* env, jclass clzObject);
static jobject JClass_doNewObjectA(JNIEnv* env, jclass clz, char* sig, jvalue* argValues);
static jboolean JClass_doIsInstanceOf(JNIEnv* env, jobject pObj, jclass clazz);
static char* JClass_doGetStringUTFChars(JNIEnv* env, jstring jstr);

static jstring JClass_doStringNew(JNIEnv* env, char* s);
static jobjectArray JClass_doNewObjectArray(JNIEnv *env, jsize len, jclass clz, jobject init);
static void JClass_doSetObjectArrayElement(JNIEnv *env, jobjectArray array, jsize index, jobject val);

static void JClass_doCallStaticVoidMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
static jobject JClass_doCallStaticObjectMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);

static void JClass_doCallVoidMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
static jobject JClass_doCallObjectMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
static jboolean JClass_doCallBooleanMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
static jdouble JClass_doCallDoubleMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);

static void JClass_printExceptionMsg(JNIEnv* env);
static void cnvEUC2UTF(const char *input, char *output);

static JClass _jclass = {
	.FP_FindClass         = JClass_doFindClass,
	.FP_GetMethodID       = JClass_doGetMethodID,
	.FP_GetStaticMethodID = JClass_doGetStaticMethodID,
	.FP_GetObjectClass    = JClass_doGetObjectClass,
	.FP_NewObjectA        = JClass_doNewObjectA,
	.FP_IsInstanceOf      = JClass_doIsInstanceOf,
	.FP_GetStringUTFChars = JClass_doGetStringUTFChars,
	
	.FP_StringNew         = JClass_doStringNew,
	.FP_NewObjectArray    = JClass_doNewObjectArray,
	.FP_SetObjectArrayElement = JClass_doSetObjectArrayElement,
	
	.FP_CallStaticVoidMethodA = JClass_doCallStaticVoidMethodA,
	.FP_CallStaticObjectMethodA = JClass_doCallStaticObjectMethodA,
	
	.FP_CallVoidMethodA       = JClass_doCallVoidMethodA,
	.FP_CallObjectMethodA     = JClass_doCallObjectMethodA,
	.FP_CallBooleanMethodA    = JClass_doCallBooleanMethodA,
	.FP_CallDoubleMethodA     = JClass_doCallDoubleMethodA,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jclass JClass_FindClass(JNIEnv* env, char* className)
{
	assert(env != 0);
	return _jclass.FP_FindClass(env, className);
}
jmethodID JClass_GetMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig)
{
	assert(env != 0);
	assert(clz != 0);
	return _jclass.FP_GetMethodID(env, clz, funcName, sig);
}
jmethodID JClass_GetStaticMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig)
{
	assert(env != 0);
	assert(clz != 0);
	return _jclass.FP_GetStaticMethodID(env, clz, funcName, sig);
}
jclass JClass_GetObjectClass(JNIEnv* env, jclass clzObject)
{
	assert(env != 0);
	assert(clzObject != 0);
	return _jclass.FP_GetObjectClass(env, clzObject);
}
jobject JClass_NewObjectA(JNIEnv* env, jclass clz, char* sig, jvalue* argValues)
{
	assert(env != 0);
	assert(clz != 0);
	return _jclass.FP_NewObjectA(env, clz, sig, argValues);
}
jboolean JClass_IsInstanceOf(JNIEnv* env, jobject pObj, jclass clazz)
{
	assert(env != NULL);
	assert(pObj != NULL);
	assert(clazz != NULL);
	return _jclass.FP_IsInstanceOf(env, pObj, clazz);
}
char* JClass_GetStringUTFChars(JNIEnv* env, jstring jstr)
{
	assert(env != NULL);
	assert(jstr != NULL);
	return _jclass.FP_GetStringUTFChars(env, jstr);
}

jstring JClass_StringNew(JNIEnv* env, char* s)
{
	assert(env != 0);
	return _jclass.FP_StringNew(env, s);
}
jobjectArray JClass_NewObjectArray(JNIEnv *env, jsize len, jclass clz, jobject init)
{
	assert(env != 0);
	assert(clz != 0);
	return _jclass.FP_NewObjectArray(env, len, clz, init);
}
void JClass_SetObjectArrayElement(JNIEnv *env, jobjectArray array, jsize index, jobject val)
{
	assert(env != 0);
	assert(array != 0);
	assert(val != 0);
	_jclass.FP_SetObjectArrayElement(env, array, index, val);
	
}
void JClass_CallStaticVoidMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args)
{
	assert(env != NULL);
	assert(clz != 0);
	assert(mid != 0);
	_jclass.FP_CallStaticVoidMethodA(env, clz, mid, args);
}
jobject JClass_CallStaticObjectMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args)
{
	assert(env != 0);
	assert(clz != 0);
	assert(mid != 0);
	return _jclass.FP_CallStaticObjectMethodA(env, clz, mid, args);
}

void JClass_CallVoidMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	assert(env != NULL);
	assert(clzObject != 0);
	assert(mid != 0);
	_jclass.FP_CallObjectMethodA(env, clzObject, mid, args);
}
jobject JClass_CallObjectMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	assert(env != 0);
	assert(clzObject != 0);
	assert(mid != 0);
	return _jclass.FP_CallObjectMethodA(env, clzObject, mid, args);
}
jboolean JClass_CallBooleanMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	assert(env != 0);
	assert(clzObject != 0);
	assert(mid != 0);
	return _jclass.FP_CallBooleanMethodA(env, clzObject, mid, args);
}
jdouble JClass_CallDoubleMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	assert(env != 0);
	assert(clzObject != 0);
	assert(mid != 0);
	return _jclass.FP_CallDoubleMethodA(env, clzObject, mid, args);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jclass JClass_doFindClass(JNIEnv* env, char* className)
{
	jclass clz = (*env)->FindClass(env, className);
    JClass_printExceptionMsg(env);
    return clz;
}
static jmethodID JClass_doGetMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig)
{
	jmethodID mid = (*env)->GetMethodID(env, clz, funcName, sig);
    JClass_printExceptionMsg(env);
    return mid;
}
static jmethodID JClass_doGetStaticMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig)
{
	jmethodID mid = (*env)->GetStaticMethodID(env, clz, funcName, sig);
    JClass_printExceptionMsg(env);
    return mid;
}
static jclass JClass_doGetObjectClass(JNIEnv* env, jclass clzObject)
{
	jclass classClz = (*env)->GetObjectClass(env, clzObject);
	
    JClass_printExceptionMsg(env);
	return classClz;
}
static jobject JClass_doNewObjectA(JNIEnv* env, jclass clz, char* sig, jvalue* argValues)
{
	jmethodID mid;

	if (0 == (mid = JClass_GetMethodID(env, clz, "<init>", sig))) {
		return 0;
	}
	jobject obj = (*env)->NewObjectA(env, clz, mid, argValues);
    JClass_printExceptionMsg(env);
	return obj;
}
static jboolean JClass_doIsInstanceOf(JNIEnv* env, jobject pObj, jclass clazz)
{
	jboolean retObj = (*env)->IsInstanceOf(env, pObj, clazz);
	
    JClass_printExceptionMsg(env);
	return retObj;
}
static char* JClass_doGetStringUTFChars(JNIEnv* env, jstring jstr)
{
	jboolean isCopy;
	jsize sz = (*env)->GetStringUTFLength(env, jstr);
	const char* utf_string = (*env)->GetStringUTFChars(env, jstr, &isCopy);
	char* retStr = malloc(sizeof(char) * (sz * 3));
	
	assert(retStr != NULL);
	memset(retStr, 0x00, sz * 3);
	memcpy(retStr, utf_string, sz);
	if (JNI_TRUE == isCopy) {
		(*env)->ReleaseStringUTFChars(env, jstr, utf_string);
	}
	return retStr;
}



static jstring JClass_doStringNew(JNIEnv* env, char* s)
{
    char* utf8;
	int len = strlen(s);
	
	utf8 = malloc(sizeof(char) * (len * 3));
	assert(utf8 != NULL);
	memset(utf8, 0x00, len * 3);
	cnvEUC2UTF(s, utf8);
	jstring jstr = (*env)->NewStringUTF(env, utf8);
    JClass_printExceptionMsg(env);
	assert(jstr != 0);
	free(utf8);
	return jstr;
}
static jobjectArray JClass_doNewObjectArray(JNIEnv *env, jsize len, jclass clz, jobject init)
{
	jobjectArray retObj = (*env)->NewObjectArray(env, len, clz, init);
	
    JClass_printExceptionMsg(env);
	return retObj;
}
static void JClass_doSetObjectArrayElement(JNIEnv *env, jobjectArray array, jsize index, jobject val)
{
	(*env)->SetObjectArrayElement(env, array, index, val);
    JClass_printExceptionMsg(env);
}
static void JClass_doCallStaticVoidMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args)
{
    (*env)->CallStaticVoidMethodA(env, clz, mid, args);
    JClass_printExceptionMsg(env);
}
static jobject JClass_doCallStaticObjectMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args)
{
	jobject jRet = (*env)->CallStaticObjectMethodA(env, clz, mid, args);
	
    JClass_printExceptionMsg(env);
	return jRet;
}

static void JClass_doCallVoidMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	(*env)->CallVoidMethodA(env, clzObject, mid, args);
    JClass_printExceptionMsg(env);
}
static jobject JClass_doCallObjectMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	jobject jRet = (*env)->CallObjectMethodA(env, clzObject, mid, args);
	
    JClass_printExceptionMsg(env);
	return jRet;
}
static jboolean JClass_doCallBooleanMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	jboolean jRet = (*env)->CallBooleanMethodA(env, clzObject, mid, args);
	
    JClass_printExceptionMsg(env);
	return jRet;
}
static jdouble JClass_doCallDoubleMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args)
{
	jdouble jRet = (*env)->CallDoubleMethodA(env, clzObject, mid, args);
	
    JClass_printExceptionMsg(env);
	return jRet;
}


static void JClass_printExceptionMsg(JNIEnv* env)
{
	assert(env != NULL);
    jthrowable throwObj = (*env)->ExceptionOccurred(env);
    
    if (throwObj != NULL) {
        (*env)->ExceptionDescribe(env);
        (*env)->ExceptionClear(env);
    }
}
static void cnvEUC2UTF(const char *input, char *output)
{
    char **inbuf;
    char **outbuf;
    iconv_t cd;
    size_t nconv;
    size_t inlen;
    size_t avail;

	assert(input != NULL);
	assert(output != NULL);
    if ((iconv_t)-1 == (cd = iconv_open("UTF-8", "EUC-JP"))) {
        fprintf(stderr, "iconv_open error\n");
        return;
    }
    inbuf = (char **)&input;
    inlen = strlen(*inbuf);
    outbuf = (char **)&output;
    avail = inlen * 4 + 1;
    if ((size_t)-1 == (nconv = iconv(cd, inbuf, &inlen, outbuf, &avail))) {
        fprintf(stderr, "iconv error\n");
        return;
    }
    if (0 != iconv_close(cd)) {
        fprintf(stderr, "iconv_close error\n");
        return;
    }
}
