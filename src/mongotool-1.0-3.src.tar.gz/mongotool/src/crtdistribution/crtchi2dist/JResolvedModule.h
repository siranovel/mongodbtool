#ifndef _JResolvedModule_H_
#define _JResolvedModule_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JResolvedModule JResolvedModule;

struct _JResolvedModule
{
	jobject (*FP_reference)(JNIEnv* env, jobject resolvedM);
	jstring (*FP_name)(JNIEnv* env, jobject resolvedM);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JResolvedModule_reference(JNIEnv* env, jobject resolvedM);
jstring JResolvedModule_name(JNIEnv* env, jobject resolvedM);
#endif
