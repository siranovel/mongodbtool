#ifndef _JBootLoader_H_
#define _JBootLoader_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JBootLoader JBootLoader;

struct _JBootLoader
{
	void (*FP_loadModule)(JNIEnv* env, jobject mref);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JBootLoader_loadModule(JNIEnv* env, jobject mref);
#endif
