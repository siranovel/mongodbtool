#ifndef _JExponentialDistribution_H_
#define _JExponentialDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JExponentialDistribution JExponentialDistribution;

struct _JExponentialDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject expdistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define EXP_DIST "org.apache.commons.math3.distribution.ExponentialDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newExponentialDistribution(JNIEnv* env, jobject emptyM, jdouble mean);
jdouble JExponentialDistribution_inverseCumulativeProbability(JNIEnv* env, jobject expdistObj, double p);
#endif
