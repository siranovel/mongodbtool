#ifndef _CCrtFDist_H_
#define _CCrtFDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtFDist CCrtFDist;

struct _CCrtFDist
{
	void (*FP_crtFInv)(CCrtFDist* pThis, double nf, double df, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtFDist* getCrtFDist(char* modPth, char* url);
void CCrtFDist_ctor(CCrtFDist* pThis, char* modPth, char* url);
void CCrtFDist_dtor(CCrtFDist* pThis);
void CCrtFDist_crtFInv(CCrtFDist* pThis, double nf, double df, double p);
#endif
