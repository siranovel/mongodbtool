#ifndef _JFDistribution_H_
#define _JFDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JFDistribution JFDistribution;

struct _JFDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject fdistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define F_DIST "org.apache.commons.math3.distribution.FDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newFDistribution(JNIEnv* env, jobject emptyM, jdouble nf, jdouble df);
jdouble JFDistribution_inverseCumulativeProbability(JNIEnv* env, jobject fdistObj, double p);
#endif
