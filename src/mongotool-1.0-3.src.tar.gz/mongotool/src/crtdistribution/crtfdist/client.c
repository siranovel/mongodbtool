#include <stdio.h>
#include <assert.h>
#include "CCrtFDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
void crtFDist(CCrtFDist* pThis, double nf, double df, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double nf = 0.0;
	double df = 0.0;

	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &nf);
	sscanf(argv[3], "%lf", &df);
	char* url = (5 == argc) ? argv[4] : URL;
	
	CCrtFDist* pThis = getCrtFDist(updModPth, url);
	
	crtFDist(pThis, nf, df, dt);
	CCrtFDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <numeratorDegreesOfFreedom> <degreesOfFreedom> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tnf > 0\n");
	printf("\tdf > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtFDist(CCrtFDist* pThis, double nf, double df, double dt)
{
	int i;
	int j;
	
	for (j = 0; j < df; j++) { 
		for (i = 0; i < nf; i++) {
			CCrtFDist_crtFInv(pThis, i + 1, j + 1, 0.05);
			CCrtFDist_crtFInv(pThis, i + 1, j + 1, 0.025);
		}
	}
}
