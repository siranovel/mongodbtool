#ifndef _CCrtLogNDist_H_
#define _CCrtLogNDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtLogNDist CCrtLogNDist;

struct _CCrtLogNDist
{
	void (*FP_crtLogNormInv)(CCrtLogNDist* pThis, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT 0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtLogNDist* getCrtLogNDist(char* modPth, char* url);
void CCrtLogNDist_ctor(CCrtLogNDist* pThis, char* modPth, char* url);
void CCrtLogNDist_dtor(CCrtLogNDist* pThis);
void CCrtLogNDist_crtLogNormInv(CCrtLogNDist* pThis, double p);
#endif
