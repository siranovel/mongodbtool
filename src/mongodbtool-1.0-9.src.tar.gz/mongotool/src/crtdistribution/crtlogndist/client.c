#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "CCrtLogNDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
void crtLogNDist(CCrtLogNDist* pThis, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	
	if (2 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	char* url = (3 == argc) ? argv[2] : URL;
	CCrtLogNDist* pThis = getCrtLogNDist(updModPth, url);
	
	crtLogNDist(pThis, dt);
	CCrtLogNDist_dtor(pThis);
    return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("%s <commons math3 Module Path> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtLogNDist(CCrtLogNDist* pThis, double dt)
{
	double p;
	
	for (p = 0; p < 1; p+=dt) {
		CCrtLogNDist_crtLogNormInv(pThis, p);
	}
}
