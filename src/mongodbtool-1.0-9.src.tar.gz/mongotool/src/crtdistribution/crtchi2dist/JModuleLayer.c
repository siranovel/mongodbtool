#include <stdio.h>
#include <assert.h>
#include "JModuleLayer.h"

static jobject JModuleLayer_doBoot(JNIEnv* env);
static jobject JModuleLayer_doConfiguration(JNIEnv* env, jobject layer);
static jobject JModuleLayer_doModules(JNIEnv* env, jobject layer);
static jobject JModuleLayer_doDefineModules(JNIEnv* env, jobject layer, jobject cf, jobject clf);
static jobject JModuleLayer_doFindModule(JNIEnv* env, jobject layer, jstring name);
static jobject JModuleLayer_doFindModule_1(JNIEnv* env, jobject layer, jstring name);
static jobject JOptional_get(JNIEnv* env, jobject opt);
static jobject JModuleLayer_doFindLoader(JNIEnv* env, jobject layer, jstring name);
static JModuleLayer _jModuleLayer = {
	.FP_boot = JModuleLayer_doBoot,
	.FP_configuration = JModuleLayer_doConfiguration,
	.FP_modules = JModuleLayer_doModules,
	.FP_defineModules = JModuleLayer_doDefineModules,
	.FP_findModule = JModuleLayer_doFindModule,
	.FP_findLoader = JModuleLayer_doFindLoader,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JModuleLayer_boot(JNIEnv* env)
{
	assert(env != 0);
	return _jModuleLayer.FP_boot(env);
}
jobject JModuleLayer_configuration(JNIEnv* env, jobject layer)
{
	assert(env != 0);
	return _jModuleLayer.FP_configuration(env, layer);
}
jobject JModuleLayer_modules(JNIEnv* env, jobject layer)
{
	assert(env != 0);
	return _jModuleLayer.FP_modules(env, layer);
}
jobject JModuleLayer_defineModules(JNIEnv* env, jobject layer, jobject cf, jobject clf)
{
	assert(env != 0);
	return _jModuleLayer.FP_defineModules(env, layer, cf, clf);
}
jobject JModuleLayer_findModule(JNIEnv* env, jobject layer, jstring name)
{
	assert(env != 0);
	return _jModuleLayer.FP_findModule(env, layer, name);
}
jobject JModuleLayer_findLoader(JNIEnv* env, jobject layer, jstring name)
{
	assert(env != 0);
	return _jModuleLayer.FP_findLoader(env, layer, name);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JModuleLayer_doBoot(JNIEnv* env)
{
	jclass clz = JClass_FindClass(env, "java/lang/ModuleLayer");
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "boot", "()Ljava/lang/ModuleLayer;");
	return JClass_CallStaticObjectMethodA(env, clz, mid, NULL);
}
static jobject JModuleLayer_doConfiguration(JNIEnv* env, jobject layer)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, layer), "configuration", "()Ljava/lang/module/Configuration;");
	return JClass_CallObjectMethodA(env, layer, mid, NULL);
	
}
static jobject JModuleLayer_doModules(JNIEnv* env, jobject layer)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, layer), "modules", "()Ljava/util/Set;");
	return JClass_CallObjectMethodA(env, layer, mid, NULL);
}
static jobject JModuleLayer_doDefineModules(JNIEnv* env, jobject layer, jobject cf, jobject clf)
{
	jvalue argValues[] = {
		[0] = { .l = cf},
		[1] = { .l = clf}
    };
	
	
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, layer), "defineModules", "(Ljava/lang/module/Configuration;Ljava/util/function/Function;)Ljava/lang/ModuleLayer;");
	return JClass_CallObjectMethodA(env, layer, mid, argValues);
}
static jobject JModuleLayer_doFindModule(JNIEnv* env, jobject layer, jstring name)
{
	jobject om = JModuleLayer_doFindModule_1(env, layer, name);
	return JOptional_get(env, om);
}
static jobject JModuleLayer_doFindModule_1(JNIEnv* env, jobject layer, jstring name)
{
	assert(layer != 0);
	jvalue argValues[] = {
		[0] = { .l = name},
    };
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, layer), "findModule", "(Ljava/lang/String;)Ljava/util/Optional;");
	
	return JClass_CallObjectMethodA(env, layer, mid, argValues);
}
static jobject JOptional_get(JNIEnv* env, jobject opt)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, opt), "get", "()Ljava/lang/Object;");
	return JClass_CallObjectMethodA(env, opt, mid, NULL);
}
static jobject JModuleLayer_doFindLoader(JNIEnv* env, jobject layer, jstring name)
{
	jvalue argValues[] = {
		[0] = { .l = name},
    };
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, layer), "findLoader", "(Ljava/lang/String;)Ljava/lang/ClassLoader;");
	return JClass_CallObjectMethodA(env, layer, mid, argValues);
}
