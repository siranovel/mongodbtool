#include <stdio.h>
#include <assert.h>
#include "JResolvedModule.h"

static jobject JResolvedModule_doReference(JNIEnv* env, jobject resolvedM);
static jstring JResolvedModule_doName(JNIEnv* env, jobject resolvedM);
static JResolvedModule _jResolvedModule = {
	.FP_reference = JResolvedModule_doReference,
	.FP_name = JResolvedModule_doName,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JResolvedModule_reference(JNIEnv* env, jobject resolvedM)
{
	return _jResolvedModule.FP_reference(env, resolvedM);
}
jstring JResolvedModule_name(JNIEnv* env, jobject resolvedM)
{
	return _jResolvedModule.FP_name(env, resolvedM);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JResolvedModule_doReference(JNIEnv* env, jobject resolvedM)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, resolvedM), "reference", "()Ljava/lang/module/ModuleReference;");
	return JClass_CallObjectMethodA(env, resolvedM, mid, NULL);
}
static jstring JResolvedModule_doName(JNIEnv* env, jobject resolvedM)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, resolvedM), "name", "()Ljava/lang/String;");
	return (jstring)JClass_CallObjectMethodA(env, resolvedM, mid, NULL);
}
