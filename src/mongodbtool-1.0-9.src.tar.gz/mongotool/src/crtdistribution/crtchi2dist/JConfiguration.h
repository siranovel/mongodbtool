#ifndef _JConfiguration_H_
#define _JConfiguration_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JConfiguration JConfiguration;

struct _JConfiguration
{
	jobject (*FP_resolveAndBind)(JNIEnv* env, jobject cf, jobject before, jobject after, jobject roots);
	jobject (*FP_modules)(JNIEnv* env, jobject cf);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JConfiguration_resolveAndBind(JNIEnv* env, jobject cf, jobject before, jobject after, jobject roots);
jobject JConfiguration_modules(JNIEnv* env, jobject cf);
#endif
