#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "CCrtGNDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtGNDist(CCrtGNDist* pThis, double df, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double df = 0.0;
	
	if (3 > argc) {
		usage(argv[0], URL);
		exit(0);
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &df);
	char* url = (4 == argc) ? argv[3] : URL;
	CCrtGNDist* pThis = getCrtGNDist(updModPth, url);
	
	crtGNDist(pThis, df, dt);
	CCrtGNDist_dtor(pThis);
    return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <degreesOfFreedom> | <mongodbURL>\n", exeNm);
	printf("\n");
	printf("\tdf > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtGNDist(CCrtGNDist* pThis, double df, double dt)
{
	int i;
	
	for (i = 2; i < df; i++) {
		CCrtGNDist_crtGNInv(pThis, i + 1, 0.05);
		CCrtGNDist_crtGNInv(pThis, i + 1, 0.025);
	}
}
