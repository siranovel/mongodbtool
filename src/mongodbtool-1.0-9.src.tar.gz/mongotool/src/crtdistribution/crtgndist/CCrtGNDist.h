#ifndef _CCrtGNDist_H_
#define _CCrtGNDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtGNDist CCrtGNDist;

struct _CCrtGNDist
{
	void (*FP_crtGNInv)(CCrtGNDist* pThis, double df, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtGNDist* getCrtGNDist(char* modPth, char* url);
void CCrtGNDist_ctor(CCrtGNDist* pThis, char* modPth, char* url);
void CCrtGNDist_dtor(CCrtGNDist* pThis);
void CCrtGNDist_crtGNInv(CCrtGNDist* pThis, double df, double p);
#endif
