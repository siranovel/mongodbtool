#ifndef _CCrtBeBiDist_H_
#define _CCrtBeBiDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtBeBiDist CCrtBeBiDist;

struct _CCrtBeBiDist
{
	void (*FP_crtBeBi)(CCrtBeBiDist* pThis, int x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtBeBiDist* getCrtBeBiDist(char* modPth, char* url, int trials, double alpha, double beta);
void CCrtBeBiDist_ctor(CCrtBeBiDist* pThis, char* modPth, char* url, int trials, double alpha, double beta);
void CCrtBeBiDist_dtor(CCrtBeBiDist* pThis);
void CCrtBeBiDist_crtBeBi(CCrtBeBiDist* pThis, int x);
#endif
