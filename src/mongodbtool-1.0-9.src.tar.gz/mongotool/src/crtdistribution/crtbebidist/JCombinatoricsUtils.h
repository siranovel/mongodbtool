#ifndef _JCombinatoricsUtils_H_
#define _JCombinatoricsUtils_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JCombinatoricsUtils JCombinatoricsUtils;

struct _JCombinatoricsUtils
{
	jlong (*FP_binomialCoefficient)(JNIEnv* env, jobject emptyM, jint n, jint k);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CombinatoricsUtils "org.apache.commons.math3.util.CombinatoricsUtils"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jlong JCombinatoricsUtils_binomialCoefficient(JNIEnv* env, jobject emptyM, jint n, jint k);
#endif
