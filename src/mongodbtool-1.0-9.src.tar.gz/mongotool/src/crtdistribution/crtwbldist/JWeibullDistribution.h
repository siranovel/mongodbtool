#ifndef _JWeibullDistribution_H_
#define _JWeibullDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JWeibullDistribution JWeibullDistribution;

struct _JWeibullDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject weidistObj, jdouble p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define WEI_DIST "org.apache.commons.math3.distribution.WeibullDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newWeibullDistribution(JNIEnv* env, jobject emptyM, jdouble alpha, jdouble beta);
jdouble JWeibullDistribution_inverseCumulativeProbability(JNIEnv* env, jobject weidistObj, jdouble p);
#endif
