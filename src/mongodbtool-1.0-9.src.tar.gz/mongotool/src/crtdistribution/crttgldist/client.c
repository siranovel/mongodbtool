#include <stdio.h>
#include <assert.h>
#include "CCrtTglDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
static void crtTglDist(CCrtTglDist* pThis, double a, double b, double c, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double a = 0.0;
	double b = 0.0;
	double c = 0.0;

	if (5 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &a);
	sscanf(argv[3], "%lf", &b);
	sscanf(argv[4], "%lf", &c);
	char* url = (6 == argc) ? argv[5] : URL;
	CCrtTglDist* pThis = getCrtTglDist(updModPth, url);
	
	crtTglDist(pThis, a, b, c, dt);
	CCrtTglDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <a> <b> <c> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\ta > 0\n");
	printf("\tb > 0\n");
	printf("\tc > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
static void crtTglDist(CCrtTglDist* pThis, double a, double b, double c, double dt)
{
	CCrtTglDist_crtTglDist(pThis, a, c, b, 0.05);
}
