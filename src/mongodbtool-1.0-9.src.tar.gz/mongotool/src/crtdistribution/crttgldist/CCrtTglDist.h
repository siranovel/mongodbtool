#ifndef _CCrtTglDist_H_
#define _CCrtTglDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtTglDist CCrtTglDist;

struct _CCrtTglDist
{
	void (*FP_crtTglDist)(CCrtTglDist* pThis, double a, double c, double b, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtTglDist* getCrtTglDist(char* modPth, char* url);
void CCrtTglDist_ctor(CCrtTglDist* pThis, char* modPth, char* url);
void CCrtTglDist_dtor(CCrtTglDist* pThis);
void CCrtTglDist_crtTglDist(CCrtTglDist* pThis, double a, double c, double b, double p);
#endif
