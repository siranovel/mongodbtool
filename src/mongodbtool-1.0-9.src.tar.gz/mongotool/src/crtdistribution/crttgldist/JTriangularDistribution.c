#include <stdio.h>
#include <assert.h>
#include "JTriangularDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewTriangularDistribution(JNIEnv* env, jobject emptyM, jdouble a, jdouble c, jdouble b);
static jdouble JTriangularDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject tglDistObj, jdouble p);
static JTriangularDistribution _jTglDist = {
	.FP_inverseCumulativeProbability = JTriangularDistribution_doInverseCumulativeProbability,
};
jobject newTriangularDistribution(JNIEnv* env, jobject emptyM, jdouble a, jdouble c, jdouble b)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewTriangularDistribution(env, emptyM, a, c, b);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JTriangularDistribution_inverseCumulativeProbability(JNIEnv* env, jobject tglDistObj, jdouble p)
{
	assert(0 != env);
	assert(0 != tglDistObj);
	return _jTglDist.FP_inverseCumulativeProbability(env, tglDistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewTriangularDistribution(JNIEnv* env, jobject emptyM, jdouble a, jdouble c, jdouble b)
{
	jvalue argValues[] = {
		[0] = { .d = a},
		[1] = { .d = c},
		[2] = { .d = b},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,TGL_DIST));
	
	return JClass_NewObjectA(env, clz, "(DDD)V", argValues);
}
static jdouble JTriangularDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject tglDistObj, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, tglDistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, tglDistObj, mid, argValues);
}
