#ifndef _CCrtLogDist_H_
#define _CCrtLogDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtLogDist CCrtLogDist;

struct _CCrtLogDist
{
	void (*FP_crtLogDist)(CCrtLogDist* pThis, double mu, double s, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtLogDist* getCrtLogDist(char* modPth, char* url);
void CCrtLogDist_ctor(CCrtLogDist* pThis, char* modPth, char* url);
void CCrtLogDist_dtor(CCrtLogDist* pThis);
void CCrtLogDist_crtLogDist(CCrtLogDist* pThis, double mu, double s, double p);
#endif
