#ifndef _JGumbelDistribution_H_
#define _JGumbelDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JGumbelDistribution JGumbelDistribution;

struct _JGumbelDistribution
{
	jdouble (*FP_inverseCumulativeProbability)(JNIEnv* env, jobject gudistObj, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define GU_DIST "org.apache.commons.math3.distribution.GumbelDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newGumbelDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta);
jdouble JGumbelDistribution_inverseCumulativeProbability(JNIEnv* env, jobject gudistObj, double p);
#endif
