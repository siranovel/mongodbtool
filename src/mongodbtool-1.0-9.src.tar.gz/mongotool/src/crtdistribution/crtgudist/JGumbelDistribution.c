#include <stdio.h>
#include <assert.h>
#include "JGumbelDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewGumbelDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta);
static jdouble JGumbelDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject gudistObj, double p);
static JGumbelDistribution _jGuDist = {
	.FP_inverseCumulativeProbability = JGumbelDistribution_doInverseCumulativeProbability,
};
jobject newGumbelDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta)
{
	assert(0 != env);
	assert(0 != emptyM);
	return doNewGumbelDistribution(env, emptyM, mu, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGumbelDistribution_inverseCumulativeProbability(JNIEnv* env, jobject gudistObj, double p)
{
	assert(0 != env);
	assert(0 != gudistObj);
	return _jGuDist.FP_inverseCumulativeProbability(env, gudistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewGumbelDistribution(JNIEnv* env, jobject emptyM, jdouble mu, jdouble beta)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = beta},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GU_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JGumbelDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject gudistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, gudistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, gudistObj, mid, argValues);
}
