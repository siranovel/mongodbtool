#include <stdio.h>
#include <assert.h>
#include "CCrtGUDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
void crtGUDist(CCrtGUDist* pThis, double mu, double beta);
int main(int argc, char* argv[])
{
	double mu = 0;
	double beta = 0;
	
	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &beta);
	char* url = (5 == argc) ? argv[4] : URL;
	
	CCrtGUDist* pThis = getCrtGUDist(updModPth, url);
	crtGUDist(pThis, mu, beta);
	CCrtGUDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <mu> <beta> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmu > 0\n");
	printf("\tbeta > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}

void crtGUDist(CCrtGUDist* pThis, double mu, double beta)
{
	CCrtGUDist_crtGUDist(pThis, mu, beta, 0.05);
}
