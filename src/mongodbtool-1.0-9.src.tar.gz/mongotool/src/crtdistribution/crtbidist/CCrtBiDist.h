#ifndef _CCrtBiDist_H_
#define _CCrtBiDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtBiDist CCrtBiDist;

struct _CCrtBiDist
{
	void(*FP_crtBiDist)(CCrtBiDist* pThis, int trials, double mu, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtBiDist* getCCrtBiDist(char* modPth, char* url);
void CCrtBiDist_ctor(CCrtBiDist* pThis, char* modPth, char* url);
void CCrtBiDist_dtor(CCrtBiDist* pThis);
void CCrtBiDist_crtBiDist(CCrtBiDist* pThis, int trials, double mu, double p);
#endif
