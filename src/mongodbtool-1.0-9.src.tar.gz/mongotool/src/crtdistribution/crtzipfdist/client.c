#include <stdio.h>
#include <assert.h>
#include "CCrtZipfDist.h"


#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
void crtZipfDist(CCrtZipfDist* pThis, int nElm, double exponent, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
    int nElm = 0;
    double exponent = 0.0;
	
	if (4 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &nElm);
	sscanf(argv[3], "%lf", &exponent);
	char* url = (5 == argc) ? argv[4] : URL;
	
	CCrtZipfDist* pThis = getCrtZipfDist(updModPth, url);
	
	crtZipfDist(pThis, nElm, exponent, dt);
	CCrtZipfDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <numberOfElements> <exponent> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tnumberOfElements > 0\n");
	printf("\texponent > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtZipfDist(CCrtZipfDist* pThis, int nElm, double exponent, double dt)
{
	int i;
	int j;
	
	for (j = 0; j < exponent; j++) { 
		for (i = 0; i < nElm; i++) {
			CCrtZipfDist_crtZipfInv(pThis, i + 1, j + 1, 0.05);
		}
	}
}
