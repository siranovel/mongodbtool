#ifndef _CCrtZipfDist_H_
#define _CCrtZipfDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtZipfDist CCrtZipfDist;

struct _CCrtZipfDist
{
	void (*FP_crtZipfInv)(CCrtZipfDist* pThis, int nElm, double exponent, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtZipfDist* getCrtZipfDist(char* modPth, char* url);
void CCrtZipfDist_ctor(CCrtZipfDist* pThis, char* modPth, char* url);
void CCrtZipfDist_dtor(CCrtZipfDist* pThis);
void CCrtZipfDist_crtZipfInv(CCrtZipfDist* pThis, int nElm, double exponent, double p);
#endif
