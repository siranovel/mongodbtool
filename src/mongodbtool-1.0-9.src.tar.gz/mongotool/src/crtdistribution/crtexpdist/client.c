#include <stdio.h>
#include <assert.h>
#include "CCrtExpDist.h"

#define URL "mongodb://localhost:27017"
static void usage(char* exeNm, char* url);
void crtExpDist(CCrtExpDist* pThis, double mean, double dt);
int main(int argc, char* argv[])
{
	double dt = DT;
	double mean = 0.0;
	
	if (3 > argc) {
		usage(argv[0], URL);
		return 0;
	}
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mean);
	char* url = (4 == argc) ? argv[3] : URL;
	CCrtExpDist* pThis = getCrtExpDist(updModPth, url);
	
	crtExpDist(pThis, mean, dt);
	CCrtExpDist_dtor(pThis);
	return 0;
}
static void usage(char* exeNm, char* url)
{
	printf("Usage:\n");
	printf("\t%s <commons math3 Module Path> <mean> | <mongodbURL>", exeNm);
	printf("\n");
	printf("\tmean > 0\n");
	printf("\tmongodbURL	default: %s\n", url);
}
void crtExpDist(CCrtExpDist* pThis, double mean, double dt)
{
	
	CCrtExpDist_crtExpDist(pThis, mean, 0.05);
}
