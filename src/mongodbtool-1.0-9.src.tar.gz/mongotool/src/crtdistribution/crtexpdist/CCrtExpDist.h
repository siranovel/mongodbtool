#ifndef _CCrtExpDist_H_
#define _CCrtExpDist_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCrtExpDist CCrtExpDist;

struct _CCrtExpDist
{
	void (*FP_crtExpDist)(CCrtExpDist* pThis, double mean, double p);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCrtExpDist* getCrtExpDist(char* modPth, char* url);
void CCrtExpDist_ctor(CCrtExpDist* pThis, char* modPth, char* url);
void CCrtExpDist_dtor(CCrtExpDist* pThis);
void CCrtExpDist_crtExpDist(CCrtExpDist* pThis, double mean, double p);
#endif
