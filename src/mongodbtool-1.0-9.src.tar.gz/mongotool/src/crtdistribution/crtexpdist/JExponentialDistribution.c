#include <stdio.h>
#include <assert.h>
#include "JExponentialDistribution.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jobject doNewExponentialDistribution(JNIEnv* env, jobject emptyM, jdouble mean);
static jdouble JExponentialDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject expdistObj, double p);
static JExponentialDistribution _jExpDist = {
	.FP_inverseCumulativeProbability = JExponentialDistribution_doInverseCumulativeProbability,
};
jobject newExponentialDistribution(JNIEnv* env, jobject emptyM, jdouble mean)
{
	assert(env != 0);
	assert(emptyM != 0);
	
	return doNewExponentialDistribution(env, emptyM, mean);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JExponentialDistribution_inverseCumulativeProbability(JNIEnv* env, jobject expdistObj, double p)
{
	assert(env != 0);
	assert(expdistObj != 0);
	return _jExpDist.FP_inverseCumulativeProbability(env, expdistObj, p);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewExponentialDistribution(JNIEnv* env, jobject emptyM, jdouble mean)
{
	jvalue argValues[] = {
		[0] = { .d = mean},
	};
	jobject loader = JModuleLayer_findLoader(env, emptyM, JClass_StringNew(env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,EXP_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JExponentialDistribution_doInverseCumulativeProbability(JNIEnv* env, jobject expdistObj, double p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, expdistObj), "inverseCumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, expdistObj, mid, argValues);
}

